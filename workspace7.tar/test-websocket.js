// Test script to verify WebSocket subscription formats based on CoinEx documentation

const testSubscriptions = {
  // Depth subscription (working)
  depth: {
    method: 'depth.subscribe',
    params: {
      market_list: [['BTCUSDT', 10, '0', true]]
    },
    id: 1
  },
  
  // Kline subscription - let's try different formats
  kline: {
    method: 'kline.subscribe',
    params: {
      market_list: [['BTCUSDT', '1min']]
    },
    id: 2
  },
  
  // Trades/Deals subscription
  trades: {
    method: 'deals.subscribe',
    params: {
      market_list: [['BTCUSDT']]
    },
    id: 3
  },
  
  // Market overview subscription
  market: {
    method: 'market.subscribe',
    params: {
      market_list: [['BTCUSDT']]
    },
    id: 4
  },
  
  // Market ticker subscription
  ticker: {
    method: 'market_ticker.subscribe',
    params: {
      market_list: [['BTCUSDT']]
    },
    id: 6
  },
  
  // Positions subscription (requires authentication)
  positions: {
    method: 'position.subscribe',
    params: {
      market_list: ['BTCUSDT']
    },
    id: 5
  }
};

console.log('WebSocket Subscription Formats for CoinEx:');
console.log(JSON.stringify(testSubscriptions, null, 2));

// According to CoinEx documentation, the format should be:
// For public data (no auth needed): depth, kline, deals, market, market_ticker
// For private data (auth needed): position