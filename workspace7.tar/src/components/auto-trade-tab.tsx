'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAutoTradeEngine } from '@/hooks/use-auto-trade-engine';
import { strategyManager } from '@/lib/strategies/strategy-manager';
import { AutoTradeEngine, AutoTradeConfig, SignalLog } from '@/lib/auto-trade-engine';
import { Play, Square, RotateCcw, Settings, Activity } from 'lucide-react';

interface StrategyParam {
  name: string;
  label: string;
  type: 'number' | 'boolean' | 'select';
  min?: number;
  max?: number;
  step?: number;
  default: any;
  options?: Array<{ value: any; label: string }>;
}

export function AutoTradeTab() {
  const {
    autoTradeEngine,
    isConnected,
    startAutoTrade,
    stopAutoTrade,
    getSignalLogs,
    clearSignalLogs,
    getStatus,
    config: tradingConfig
  } = useAutoTradeEngine();

  // 配置状态
  const [config, setConfig] = useState<Partial<AutoTradeConfig>>({
    symbol: tradingConfig?.symbol || 'XRPUSDT',
    timeframe: tradingConfig?.timeframe || '5m',
    amount: tradingConfig?.amountUsdt || 20,
    leverage: tradingConfig?.leverage || 5,
    marginMode: tradingConfig?.marginMode || 'cross',
    takeProfitPercent: tradingConfig?.profitPercent || 1,
    stopLossPercent: tradingConfig?.lossPercent || 1,
    strategy: 'range-filter',
    strategyParams: {}
  });

  // 获取当前状态和日志
  const status = getStatus();
  const isActive = status?.isActive || false;
  const signalLogs = getSignalLogs();

  // 策略配置
  const [strategyConfigs, setStrategyConfigs] = useState<Array<{
    name: string;
    displayName: string;
    params: StrategyParam[];
  }>>([]);

  // 初始化策略配置
  useEffect(() => {
    const configs = strategyManager.getAllStrategyConfigs();
    setStrategyConfigs(configs);
  }, []);

  // 处理配置变化
  const handleConfigChange = useCallback((key: keyof AutoTradeConfig, value: any) => {
    setConfig(prev => ({
      ...prev,
      [key]: value
    }));
  }, []);

  // 处理策略参数变化
  const handleStrategyParamChange = useCallback((paramName: string, value: any) => {
    setConfig(prev => ({
      ...prev,
      strategyParams: {
        ...prev.strategyParams,
        [paramName]: value
      }
    }));
  }, []);

  // 开始自动交易
  const handleStart = useCallback(() => {
    if (!config.strategy || !config.timeframe) {
      return;
    }

    const fullConfig: AutoTradeConfig = {
      symbol: config.symbol || 'XRPUSDT',
      timeframe: config.timeframe,
      amount: config.amount || 20,
      leverage: config.leverage || 5,
      marginMode: config.marginMode || 'cross',
      takeProfitPercent: config.takeProfitPercent || 1,
      stopLossPercent: config.stopLossPercent || 1,
      strategy: config.strategy,
      strategyParams: config.strategyParams || {}
    };

    startAutoTrade(fullConfig);
  }, [startAutoTrade, config]);

  // 停止自动交易
  const handleStop = useCallback(() => {
    stopAutoTrade();
  }, [stopAutoTrade]);

  // 清除日志
  const handleClearLogs = useCallback(() => {
    clearSignalLogs();
  }, [clearSignalLogs]);

  // 获取当前策略的参数配置
  const currentStrategyParams = strategyConfigs.find(s => s.name === config.strategy)?.params || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Auto Trade</h1>
          <p className="text-muted-foreground">
            Automated trading based on strategy signals
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant={isActive ? "default" : "secondary"}>
            {isActive ? "Active" : "Inactive"}
          </Badge>
          {isActive ? (
            <Button onClick={handleStop} variant="destructive" size="sm">
              <Square className="w-4 h-4 mr-2" />
              Stop
            </Button>
          ) : (
            <Button onClick={handleStart} disabled={!isConnected} size="sm">
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="settings" className="space-y-4">
        <TabsList>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="logs">Signal Logs</TabsTrigger>
          <TabsTrigger value="backtest">Backtest</TabsTrigger>
        </TabsList>

        <TabsContent value="settings" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 策略配置 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Strategy Configuration
                </CardTitle>
                <CardDescription>
                  Select and configure your trading strategy
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="strategy">Strategy</Label>
                  <Select
                    value={config.strategy}
                    onValueChange={(value) => handleConfigChange('strategy', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select strategy" />
                    </SelectTrigger>
                    <SelectContent>
                      {strategyConfigs.map((strategy) => (
                        <SelectItem key={strategy.name} value={strategy.name}>
                          {strategy.displayName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* 策略参数 */}
                {currentStrategyParams.length > 0 && (
                  <div className="space-y-4">
                    <Label>Strategy Parameters</Label>
                    {currentStrategyParams.map((param) => (
                      <div key={param.name} className="space-y-2">
                        <Label htmlFor={param.name}>{param.label}</Label>
                        {param.type === 'number' && (
                          <Input
                            id={param.name}
                            type="number"
                            step={param.step}
                            min={param.min}
                            max={param.max}
                            value={config.strategyParams?.[param.name] ?? param.default}
                            onChange={(e) => handleStrategyParamChange(param.name, parseFloat(e.target.value))}
                          />
                        )}
                        {param.type === 'boolean' && (
                          <Switch
                            id={param.name}
                            checked={config.strategyParams?.[param.name] ?? param.default}
                            onCheckedChange={(checked) => handleStrategyParamChange(param.name, checked)}
                          />
                        )}
                        {param.type === 'select' && param.options && (
                          <Select
                            value={config.strategyParams?.[param.name] ?? param.default}
                            onValueChange={(value) => handleStrategyParamChange(param.name, value)}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {param.options.map((option) => (
                                <SelectItem key={option.value} value={option.value}>
                                  {option.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 交易配置 */}
            <Card>
              <CardHeader>
                <CardTitle>Trading Configuration</CardTitle>
                <CardDescription>
                  Configure your trading parameters
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="symbol">Symbol</Label>
                    <Input
                      id="symbol"
                      value={config.symbol}
                      onChange={(e) => handleConfigChange('symbol', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timeframe">Timeframe</Label>
                    <Select
                      value={config.timeframe}
                      onValueChange={(value) => handleConfigChange('timeframe', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1m">1 Minute</SelectItem>
                        <SelectItem value="3m">3 Minutes</SelectItem>
                        <SelectItem value="5m">5 Minutes</SelectItem>
                        <SelectItem value="15m">15 Minutes</SelectItem>
                        <SelectItem value="30m">30 Minutes</SelectItem>
                        <SelectItem value="1h">1 Hour</SelectItem>
                        <SelectItem value="2h">2 Hours</SelectItem>
                        <SelectItem value="4h">4 Hours</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (USDT)</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={config.amount}
                      onChange={(e) => handleConfigChange('amount', parseFloat(e.target.value))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="leverage">Leverage</Label>
                    <Input
                      id="leverage"
                      type="number"
                      value={config.leverage}
                      onChange={(e) => handleConfigChange('leverage', parseInt(e.target.value))}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="marginMode">Margin Mode</Label>
                  <Select
                    value={config.marginMode}
                    onValueChange={(value) => handleConfigChange('marginMode', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cross">Cross</SelectItem>
                      <SelectItem value="isolated">Isolated</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="takeProfit">Take Profit (%)</Label>
                    <Input
                      id="takeProfit"
                      type="number"
                      step="0.1"
                      value={config.takeProfitPercent}
                      onChange={(e) => handleConfigChange('takeProfitPercent', parseFloat(e.target.value))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="stopLoss">Stop Loss (%)</Label>
                    <Input
                      id="stopLoss"
                      type="number"
                      step="0.1"
                      value={config.stopLossPercent}
                      onChange={(e) => handleConfigChange('stopLossPercent', parseFloat(e.target.value))}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 状态信息 */}
          {status && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Buffer Size</p>
                    <p className="text-2xl font-bold">{status.bufferSize}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Strategy</p>
                    <p className="text-lg font-semibold">{status.config?.strategy}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Timeframe</p>
                    <p className="text-lg font-semibold">{status.config?.timeframe}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Last Signal</p>
                    <p className="text-lg font-semibold">
                      {status.lastSignalTime ? new Date(status.lastSignalTime).toLocaleTimeString() : 'Never'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Signal Logs</CardTitle>
                  <CardDescription>
                    Real-time strategy signals and execution status
                  </CardDescription>
                </div>
                <Button onClick={handleClearLogs} variant="outline" size="sm">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Clear Logs
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] w-full border rounded-md p-4">
                {signalLogs.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    No signals yet. Start auto trading to see signals here.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {signalLogs.map((log) => (
                      <div
                        key={log.id}
                        className={`p-3 rounded-lg border ${
                          log.executed ? 'bg-green-50 border-green-200' : 
                          log.error ? 'bg-red-50 border-red-200' : 
                          'bg-blue-50 border-blue-200'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <Badge variant={log.signalType === 'buy' ? 'default' : 'destructive'}>
                              {log.signalType.toUpperCase()}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {new Date(log.timestamp).toLocaleString()}
                            </span>
                          </div>
                          <Badge variant={log.executed ? 'default' : log.error ? 'destructive' : 'secondary'}>
                            {log.executed ? 'Executed' : log.error ? 'Error' : 'Pending'}
                          </Badge>
                        </div>
                        <div className="text-sm">
                          <p><strong>Strategy:</strong> {log.strategy}</p>
                          <p><strong>Price:</strong> {log.price.toFixed(4)}</p>
                          {log.orderId && <p><strong>Order ID:</strong> {log.orderId}</p>}
                          {log.error && <p><strong>Error:</strong> {log.error}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backtest" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Backtest</CardTitle>
              <CardDescription>
                Strategy backtesting functionality will be implemented here.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center text-muted-foreground py-8">
                <p>Backtest functionality is coming soon.</p>
                <p className="text-sm mt-2">This will allow you to test your strategies against historical data.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}