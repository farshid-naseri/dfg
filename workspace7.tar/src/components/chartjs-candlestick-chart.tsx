'use client'

import React, { useEffect, useState, useRef, useCallback } from 'react'
import dynamic from 'next/dynamic'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import CandleChart from '@/components/candle-chart'
import '@/styles/candle-chart.css'

interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume?: number
}

interface LivePriceData {
  symbol: string
  price: number
  timestamp: number
  volume?: number
}

interface ChartDataPoint {
  x: number
  y: number[]
}

const ChartJsCandlestickChart: React.FC = () => {
  const [isClient, setIsClient] = useState(false)
  
  const [selectedSymbol, setSelectedSymbol] = useState<string>('XRPUSDT')
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>('5m')
  const [isConnected, setIsConnected] = useState<boolean>(false)
  const [lastUpdate, setLastUpdate] = useState<string>('')
  const [currentCandle, setCurrentCandle] = useState<CandleData | null>(null)
  const [chartData, setChartData] = useState<ChartDataPoint[]>([])
  const chartRef = useRef<any>(null)
  const isInitialLoad = useRef(true)
  const lastCandleTime = useRef<number>(0)
  
  // Ensure we're on client side
  useEffect(() => {
    setIsClient(true)
  }, [])
  
  // تایم‌فریم‌های موجود
  const timeframes = [
    { value: '1m', label: '1 دقیقه', seconds: 60 },
    { value: '3m', label: '3 دقیقه', seconds: 180 },
    { value: '5m', label: '5 دقیقه', seconds: 300 },
    { value: '15m', label: '15 دقیقه', seconds: 900 },
    { value: '30m', label: '30 دقیقه', seconds: 1800 },
    { value: '1h', label: '1 ساعت', seconds: 3600 },
    { value: '2h', label: '2 ساعت', seconds: 7200 },
    { value: '4h', label: '4 ساعت', seconds: 14400 },
    { value: '6h', label: '6 ساعت', seconds: 21600 },
    { value: '12h', label: '12 ساعت', seconds: 43200 },
    { value: '1d', label: '1 روز', seconds: 86400 },
  ]
  
  const symbols = [
    { value: 'BTCUSDT', label: 'BTC/USDT' },
    { value: 'ETHUSDT', label: 'ETH/USDT' },
    { value: 'XRPUSDT', label: 'XRP/USDT' },
    { value: 'ADAUSDT', label: 'ADA/USDT' },
    { value: 'SOLUSDT', label: 'SOL/USDT' },
  ]

  // دریافت داده‌های تاریخی
  const fetchHistoricalData = async (): Promise<CandleData[]> => {
    try {
      const response = await fetch(`/api/coinex/historical-data?symbol=${selectedSymbol}&timeframe=${selectedTimeframe}&limit=50`)
      if (!response.ok) {
        throw new Error('Failed to fetch historical data')
      }
      const data = await response.json()
      return data.candles || []
    } catch (error) {
      console.error('Error fetching historical data:', error)
      return []
    }
  }

  // ایجاد نمودار کندلی با ApexCharts
  const createChartInstance = async () => {
    if (!isClient) {
      console.error('Not on client side')
      return
    }

    try {
      // دریافت داده‌های تاریخی
      const historicalData = await fetchHistoricalData()
      
      let apexChartData: ChartDataPoint[] = []
      
      if (historicalData.length > 0) {
        // آماده‌سازی داده‌ها برای نمودار ApexCharts
        apexChartData = historicalData.map(candle => ({
          x: candle.time * 1000, // تبدیل به میلی‌ثانیه
          y: [candle.open, candle.high, candle.low, candle.close]
        }))
        
        // تنظیم کندل فعلی
        const lastCandle = historicalData[historicalData.length - 1]
        setCurrentCandle(lastCandle)
      } else {
        // اگر داده‌ای وجود نداشت، از داده‌های تستی استفاده کن
        console.log('No historical data available, using test data')
        const now = Date.now()
        apexChartData = [
          { x: now - 86400000, y: [6600, 6650, 6580, 6620] },
          { x: now - 72000000, y: [6620, 6640, 6600, 6630] },
          { x: now - 57600000, y: [6630, 6650, 6610, 6640] },
          { x: now - 43200000, y: [6640, 6660, 6620, 6650] },
          { x: now - 28800000, y: [6650, 6670, 6630, 6660] },
          { x: now - 14400000, y: [6660, 6680, 6640, 6670] },
          { x: now, y: [6670, 6690, 6650, 6680] }
        ]
        
        // تنظیم کندل فعلی از داده‌های تستی
        setCurrentCandle({
          time: Math.floor(now / 1000),
          open: 6670,
          high: 6690,
          low: 6650,
          close: 6680,
          volume: 1000
        })
      }

      console.log('Chart data prepared:', apexChartData)
      setChartData(apexChartData)
      
    } catch (error) {
      console.error('Error creating chart:', error)
    }
  }

  // به‌روزرسانی هوشمند نمودار بدون ریست کردن
  const updateChartSmartly = useCallback((newData: ChartDataPoint[]) => {
    if (chartRef.current && chartRef.current.chart) {
      try {
        // استفاده از API داخلی ApexCharts برای به‌روزرسانی بدون ریست
        chartRef.current.chart.updateSeries([{
          name: selectedSymbol,
          data: newData
        }], false)
      } catch (error) {
        console.error('Error updating chart smartly:', error)
        // در صورت خطا، از روش معمولی استفاده کن
        setChartData(newData)
      }
    } else {
      setChartData(newData)
    }
  }, [selectedSymbol])

  // شبیه‌سازی داده‌های زنده برای تست
  const simulateLiveData = useCallback(() => {
    if (!currentCandle) return

    const now = Math.floor(Date.now() / 1000)
    const timeframeSeconds = timeframes.find(tf => tf.value === selectedTimeframe)?.seconds || 300
    const candleStartTime = Math.floor(now / timeframeSeconds) * timeframeSeconds

    setLastUpdate(new Date().toLocaleTimeString('fa-IR'))

    // شبیه‌سازی قیمت جدید
    const randomChange = (Math.random() - 0.5) * 0.001 // 0.1% نوسان
    const newPrice = currentCandle.close * (1 + randomChange)

    // اگر هنوز در بازه زمانی کندل فعلی هستیم
    if (currentCandle.time === candleStartTime) {
      const updatedCandle = {
        ...currentCandle,
        high: Math.max(currentCandle.high, newPrice),
        low: Math.min(currentCandle.low, newPrice),
        close: newPrice,
        volume: (currentCandle.volume || 0) + Math.random() * 1000
      }
      
      setCurrentCandle(updatedCandle)
      
      // به‌روزرسانی فقط آخرین کندل در نمودار بدون ریست کردن کل داده‌ها
      if (chartData.length > 0) {
        const lastIndex = chartData.length - 1
        const newData = [...chartData]
        newData[lastIndex] = {
          x: updatedCandle.time * 1000,
          y: [updatedCandle.open, updatedCandle.high, updatedCandle.low, updatedCandle.close]
        }
        updateChartSmartly(newData)
      }
    } else {
      // کندل قبلی بسته شده، کندل جدید بساز
      const newCandle: CandleData = {
        time: candleStartTime,
        open: newPrice,
        high: newPrice,
        low: newPrice,
        close: newPrice,
        volume: Math.random() * 1000
      }
      
      setCurrentCandle(newCandle)
      lastCandleTime.current = candleStartTime
      
      // اضافه کردن کندل جدید به نمودار
      const newData = [...chartData, {
        x: newCandle.time * 1000,
        y: [newCandle.open, newCandle.high, newCandle.low, newCandle.close]
      }]
      
      // حذف داده‌های قدیمی اگر بیش از 100 تا شده باشند
      if (newData.length > 100) {
        newData.shift()
      }
      
      updateChartSmartly(newData)
    }
  }, [currentCandle, chartData, selectedTimeframe, updateChartSmartly])

  // بارگذاری مجدد داده‌ها با تغییر نماد یا تایم‌فریم
  const reloadChartData = useCallback(async () => {
    try {
      const historicalData = await fetchHistoricalData()
      
      if (historicalData.length > 0) {
        console.log('Reloading chart data:', historicalData.length, 'candles')
        
        // آماده‌سازی داده‌های جدید برای نمودار ApexCharts
        const newChartData = historicalData.map(candle => ({
          x: candle.time * 1000,
          y: [candle.open, candle.high, candle.low, candle.close]
        }))
        
        setChartData(newChartData)
        
        // تنظیم کندل فعلی
        const lastCandle = historicalData[historicalData.length - 1]
        setCurrentCandle(lastCandle)
        lastCandleTime.current = lastCandle.time
        console.log('Chart data reloaded successfully')
      } else {
        console.log('No historical data available')
      }
    } catch (error) {
      console.error('Error reloading chart data:', error)
    }
  }, [selectedSymbol, selectedTimeframe])

  useEffect(() => {
    if (isClient) {
      // تاخیر برای اطمینان از اینکه DOM آماده است
      const timer = setTimeout(() => {
        createChartInstance()
      }, 100)
      
      return () => {
        clearTimeout(timer)
      }
    }
  }, [isClient])

  useEffect(() => {
    if (isClient) {
      reloadChartData()
    }
  }, [selectedSymbol, selectedTimeframe, isClient])

  useEffect(() => {
    if (isClient && currentCandle) {
      // شبیه‌سازی داده‌های زنده هر 2 ثانیه
      const interval = setInterval(simulateLiveData, 2000)
      setIsConnected(true)
      
      return () => {
        clearInterval(interval)
        setIsConnected(false)
      }
    }
  }, [selectedSymbol, selectedTimeframe, isClient, currentCandle])

  // محاسبه بهینه فاصله بین کندل‌ها
  const calculateOptimalCandleWidth = useCallback(() => {
    if (chartData.length < 2) return '60%'
    
    const containerWidth = 800 // عرض تخمینی نمودار
    const availableWidth = containerWidth * 0.8 // 80% از عرض برای کندل‌ها
    const candleWidth = Math.max(2, Math.min(availableWidth / chartData.length, 20)) // حداکثر 20 پیکسل
    
    return `${Math.round((candleWidth / availableWidth) * 100)}%`
  }, [chartData])

  // تنظیمات نمودار ApexCharts
  const chartOptions = {
    chart: {
      type: 'candlestick',
      height: 400,
      background: 'transparent',
      toolbar: {
        show: true,
        tools: {
          download: true,
          selection: true,
          zoom: true,
          zoomin: true,
          zoomout: true,
          pan: true,
          reset: true
        }
      },
      events: {
        beforeZoom: (chart: any, { xaxis }: any) => {
          // محدود کردن زوم برای حفظ فاصله مناسب بین کندل‌ها
          if (xaxis && xaxis.min && xaxis.max) {
            const diff = xaxis.max - xaxis.min
            const minDiff = 300000 // حداقل 5 دقیقه برای نمایش مناسب کندل‌ها
            if (diff < minDiff) {
              return false
            }
          }
          return true
        }
      },
      redrawOnParentResize: false,
      redrawOnWindowResize: false
    },
    title: {
      text: `نمودار کندلی ${selectedSymbol}`,
      align: 'right',
      style: {
        fontSize: '18px',
        fontWeight: 'bold',
        fontFamily: 'system-ui'
      }
    },
    plotOptions: {
      candlestick: {
        colors: {
          upward: '#10b981',
          downward: '#ef4444'
        },
        wick: {
          useFillColor: true
        },
        columnWidth: calculateOptimalCandleWidth(), // محاسبه بهینه عرض کندل‌ها
        barWidth: calculateOptimalCandleWidth()
      }
    },
    xaxis: {
      type: 'datetime',
      labels: {
        datetimeUTC: false,
        formatter: function(value: number) {
          return new Date(value).toLocaleTimeString('fa-IR')
        }
      },
      axisBorder: {
        show: true
      },
      axisTicks: {
        show: true
      },
      crosshairs: {
        show: true
      },
      tooltip: {
        enabled: true
      },
      range: 7200000, // محدوده پیش‌فرض 2 ساعت برای نمایش بهتر
      tickAmount: 12, // تعداد تیک‌ها در محور x
      tickPlacement: 'between', // قرارگیری تیک‌ها بین کندل‌ها
      categories: chartData.map(d => d.x) // دسته‌بندی‌های سفارشی
    },
    yaxis: {
      tooltip: {
        enabled: true
      },
      labels: {
        formatter: function(value: number) {
          return value.toFixed(4)
        }
      }
    },
    tooltip: {
      enabled: true,
      custom: function({ seriesIndex, dataPointIndex, w }: any) {
        if (!w || !w.globals || !w.globals.seriesCandleO) return ''
        
        const o = w.globals.seriesCandleO[seriesIndex][dataPointIndex]
        const h = w.globals.seriesCandleH[seriesIndex][dataPointIndex]
        const l = w.globals.seriesCandleL[seriesIndex][dataPointIndex]
        const c = w.globals.seriesCandleC[seriesIndex][dataPointIndex]
        
        return (
          '<div class="apexcharts-tooltip-candlestick bg-white p-3 border rounded shadow-lg">' +
          '<div class="font-bold text-gray-800 mb-2">' + new Date(w.globals.seriesX[seriesIndex][dataPointIndex]).toLocaleString('fa-IR') + '</div>' +
          '<div class="flex justify-between"><span class="text-gray-600">Open:</span><span class="font-semibold text-green-600">' + o.toFixed(4) + '</span></div>' +
          '<div class="flex justify-between"><span class="text-gray-600">High:</span><span class="font-semibold text-blue-600">' + h.toFixed(4) + '</span></div>' +
          '<div class="flex justify-between"><span class="text-gray-600">Low:</span><span class="font-semibold text-red-600">' + l.toFixed(4) + '</span></div>' +
          '<div class="flex justify-between"><span class="text-gray-600">Close:</span><span class="font-semibold ' + (c >= o ? 'text-green-600' : 'text-red-600') + '">' + c.toFixed(4) + '</span></div>' +
          '</div>'
        )
      },
      fixed: {
        enabled: false
      }
    },
    theme: {
      mode: 'light'
    },
    grid: {
      borderColor: '#e5e7eb',
      xaxis: {
        lines: {
          show: true
        }
      },
      yaxis: {
        lines: {
          show: true
        }
      }
    },
    dataLabels: {
      enabled: false
    },
    animations: {
      enabled: false // غیرفعال کردن انیمیشن برای جلوگیری از ریست شدن
    },
    stroke: {
      width: 1,
      curve: 'straight'
    },
    markers: {
      size: 0
    },
    noData: {
      text: 'در حال دریافت داده‌ها...',
      align: 'center',
      verticalAlign: 'middle',
      style: {
        fontSize: '14px',
        fontFamily: 'system-ui'
      }
    }
  }

  const chartSeries = [
    {
      name: selectedSymbol,
      data: chartData
    }
  ]

  if (!isClient) {
    return (
      <div className="container mx-auto p-6 space-y-6" dir="rtl">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center">
              نمودار کندلی ارز دیجیتال
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">در حال بارگذاری نمودار...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">
            نمودار کندلی ارز دیجیتال
          </CardTitle>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">ارز:</label>
              <Select value={selectedSymbol} onValueChange={setSelectedSymbol}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {symbols.map((symbol) => (
                    <SelectItem key={symbol.value} value={symbol.value}>
                      {symbol.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">تایم‌فریم:</label>
              <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {timeframes.map((timeframe) => (
                    <SelectItem key={timeframe.value} value={timeframe.value}>
                      {timeframe.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">وضعیت:</span>
              <Badge variant={isConnected ? "default" : "destructive"}>
                {isConnected ? "متصل (شبیه‌سازی)" : "قطع"}
              </Badge>
            </div>
            
            {lastUpdate && (
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">آخرین به‌روزرسانی:</span>
                <span className="text-sm text-muted-foreground">{lastUpdate}</span>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="w-full h-96">
            {chartData.length > 0 ? (
              <CandleChart
                options={chartOptions}
                series={chartSeries}
                height={400}
                onChartReady={(chart) => {
                  chartRef.current = chart
                }}
              />
            ) : (
              <div className="flex flex-col items-center justify-center h-full">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground mb-2">در حال بارگذاری نمودار...</p>
                <p className="text-xs text-muted-foreground">
                  در حال دریافت داده‌ها...
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      {currentCandle && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">اطلاعات کندل فعلی</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="font-medium">زمان: </span>
                <span>{new Date(currentCandle.time * 1000).toLocaleString('fa-IR')}</span>
              </div>
              <div>
                <span className="font-medium">Open: </span>
                <span className={currentCandle.close >= currentCandle.open ? 'text-green-600' : 'text-red-600'}>
                  {currentCandle.open.toFixed(4)}
                </span>
              </div>
              <div>
                <span className="font-medium">High: </span>
                <span className="text-blue-600">{currentCandle.high.toFixed(4)}</span>
              </div>
              <div>
                <span className="font-medium">Low: </span>
                <span className="text-purple-600">{currentCandle.low.toFixed(4)}</span>
              </div>
              <div>
                <span className="font-medium">Close: </span>
                <span className={currentCandle.close >= currentCandle.open ? 'text-green-600' : 'text-red-600'}>
                  {currentCandle.close.toFixed(4)}
                </span>
              </div>
              <div>
                <span className="font-medium">تغییر: </span>
                <span className={currentCandle.close >= currentCandle.open ? 'text-green-600' : 'text-red-600'}>
                  {((currentCandle.close - currentCandle.open) / currentCandle.open * 100).toFixed(2)}%
                </span>
              </div>
              {currentCandle.volume && (
                <div>
                  <span className="font-medium">حجم: </span>
                  <span>{currentCandle.volume.toFixed(2)}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default ChartJsCandlestickChart