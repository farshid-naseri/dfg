'use client';

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useTradingEngine } from '@/hooks/use-trading-engine';


interface WebSocketDataDisplayProps {
  className?: string;
}

interface MarketData {
  symbol: string;
  lastPrice: number;
  bid: number;
  ask: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  change24h: number;
  changePercent24h: number;
}

interface MarketStateData {
  market: string;
  last: string;
  open: string;
  close: string;
  high: string;
  low: string;
  volume: string;
  value: string;
  volume_sell: string;
  volume_buy: string;
  insurance_fund_size: string;
  mark_price: string;
  index_price: string;
  open_interest_size: string;
  latest_funding_rate: string;
  next_funding_rate: string;
  latest_funding_time: number;
  next_funding_time: number;
  period: number;
}

interface PositionData {
  id: string;
  market: string;
  side: string;
  margin_mode: string;
  leverage: number;
  ath_position_amount: number;
  amount_usdt: number;
  unrealized_pnl: number;
  realized_pnl: number;
  avg_entry_price: number;
  settle_price: number;
  take_profit_price?: number;
  stop_loss_price?: number;
  liquidation_price?: string;
  margin_ratio: number;
  open_interest?: number;
  close_avbl?: number;
  cml_position_value?: number;
  max_position_value?: number;
  margin_avbl?: number;
  ath_margin_size?: number;
  maintenance_margin_rate?: number;
  maintenance_margin_value?: number;
  liq_price?: number;
  bkr_price?: number;
  adl_level?: number;
  first_filled_price?: number;
  latest_filled_price?: number;
}

interface CandleData {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface TradeData {
  timestamp: number;
  price: number;
  amount: number;
  side: string;
}

export function WebSocketDataDisplay({ className }: WebSocketDataDisplayProps) {
  const { state, engine, isInitialized, initialize, start } = useTradingEngine();
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  const [marketStateData, setMarketStateData] = useState<MarketStateData | null>(null);
  const [positions, setPositions] = useState<PositionData[]>([]);
  const [currentCandle, setCurrentCandle] = useState<CandleData | null>(null);
  const [recentTrades, setRecentTrades] = useState<TradeData[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [subscriptionStatus, setSubscriptionStatus] = useState<{
    depth: boolean;
    kline: boolean;
    trades: boolean;
    market: boolean;
    ticker: boolean;
    positions: boolean;
    state: boolean;
  }>({
    depth: false,
    kline: false,
    trades: false,
    market: false,
    ticker: false,
    positions: false,
    state: false
  });

  // API Configuration state
  const [apiConfig, setApiConfig] = useState({
    apiKey: '',
    apiSecret: '',
    symbol: 'XRPUSDT',
    leverage: 5,
    amountUsdt: 20,
    timeframe: '5min'
  });
  const [showConfig, setShowConfig] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);

  useEffect(() => {
    if (!engine) return;

    // Listen to market updates
    const handleMarketUpdate = (data: MarketData) => {
      setMarketData(data);
      setLastUpdate(new Date());
    };

    // Listen to position updates
    const handlePositionUpdate = (data: any) => {
      console.log('Position update received:', data);
      if (data && Array.isArray(data)) {
        setPositions(data);
      } else if (data && data.position) {
        // Handle single position update
        setPositions(prev => {
          const updatedPosition = data.position;
          const existingIndex = prev.findIndex(p => p.id === updatedPosition.id);
          if (existingIndex >= 0) {
            const updated = [...prev];
            updated[existingIndex] = updatedPosition;
            return updated;
          } else {
            return [...prev, updatedPosition];
          }
        });
      } else if (data) {
        setPositions([data]);
      }
      setLastUpdate(new Date());
    };

    // Listen to candle updates
    const handleCandleUpdate = (data: CandleData) => {
      setCurrentCandle(data);
      setLastUpdate(new Date());
    };

    // Listen to trade updates
    const handleTradeUpdate = (data: TradeData) => {
      setRecentTrades(prev => {
        const updated = [data, ...prev].slice(0, 10); // Keep last 10 trades
        return updated;
      });
      setLastUpdate(new Date());
    };

    // Listen to depth updates (order book)
    const handleDepthUpdate = (data: any) => {
      if (data && data.midPrice) {
        // Update current price from order book mid price
        setSubscriptionStatus(prev => ({ ...prev, depth: true }));
        setLastUpdate(new Date());
      }
    };

    // Listen to state updates (market status)
    const handleStateUpdate = (data: MarketStateData[]) => {
      if (data && data.length > 0) {
        // Find the data for our symbol
        const symbol = state.config?.symbol || 'XRPUSDT';
        const stateData = data.find(item => item.market === symbol);
        if (stateData) {
          setMarketStateData(stateData);
          setSubscriptionStatus(prev => ({ ...prev, state: true }));
          setLastUpdate(new Date());
        }
      }
    };

    // Update subscription status based on message types
    const updateSubscriptionStatus = (method: string) => {
      switch (method) {
        case 'depth.update':
          setSubscriptionStatus(prev => ({ ...prev, depth: true }));
          break;
        case 'kline.update':
          setSubscriptionStatus(prev => ({ ...prev, kline: true }));
          break;
        case 'deals.update':
          setSubscriptionStatus(prev => ({ ...prev, trades: true }));
          break;
        case 'market.update':
          setSubscriptionStatus(prev => ({ ...prev, market: true }));
          break;
        case 'market_ticker.update':
          setSubscriptionStatus(prev => ({ ...prev, ticker: true }));
          break;
        case 'position.update':
          setSubscriptionStatus(prev => ({ ...prev, positions: true }));
          break;
        case 'state.update':
          setSubscriptionStatus(prev => ({ ...prev, state: true }));
          break;
      }
      setLastUpdate(new Date());
    };

    // Listen to all WebSocket messages to track subscription status
    const handleWebSocketMessage = (message: any) => {
      if (message && message.method) {
        updateSubscriptionStatus(message.method);
      }
    };

    engine.on('marketUpdate', handleMarketUpdate);
    engine.on('positionUpdate', handlePositionUpdate);
    engine.on('candleUpdate', handleCandleUpdate);
    engine.on('tradeUpdate', handleTradeUpdate);
    engine.on('depthUpdate', handleDepthUpdate);
    engine.on('stateUpdate', handleStateUpdate);
    engine.on('websocketMessage', handleWebSocketMessage);

    // Initial data setup
    if (state.marketData) {
      setMarketData(state.marketData);
    }
    if (state.positions && state.positions.length > 0) {
      setPositions(state.positions);
    }
    if (state.candles && state.candles.length > 0) {
      setCurrentCandle(state.candles[state.candles.length - 1]);
    }

    return () => {
      engine.off('marketUpdate', handleMarketUpdate);
      engine.off('positionUpdate', handlePositionUpdate);
      engine.off('candleUpdate', handleCandleUpdate);
      engine.off('tradeUpdate', handleTradeUpdate);
      engine.off('depthUpdate', handleDepthUpdate);
      engine.off('stateUpdate', handleStateUpdate);
      engine.off('websocketMessage', handleWebSocketMessage);
    };
  }, [engine, state]);

  // Initialize trading engine with API config
  const handleInitialize = async () => {
    if (!apiConfig.apiKey || !apiConfig.apiSecret) {
      setInitError('API Key and API Secret are required');
      return;
    }

    setIsInitializing(true);
    setInitError(null);

    try {
      const config = {
        apiKey: apiConfig.apiKey,
        apiSecret: apiConfig.apiSecret,
        symbol: apiConfig.symbol,
        leverage: apiConfig.leverage,
        amountUsdt: apiConfig.amountUsdt,
        timeframe: apiConfig.timeframe,
        marginMode: 'cross' as const,
        atrPeriod: 10,
        multiplier: 3,
        profitPercent: 1,
        lossPercent: 1,
        trailPercent: 0.5,
        useAI: false,
        autoTrade: false
      };

      const success = await initialize(config);
      
      if (success) {
        // Save config to localStorage
        try {
          localStorage.setItem('tradingConfig', JSON.stringify(config));
          console.log('Trading configuration saved successfully');
        } catch (error) {
          console.error('Failed to save trading configuration:', error);
          setInitError('Failed to save configuration');
          return;
        }
        setShowConfig(false);
        
        // Start the engine after initialization
        await start();
      } else {
        setInitError('Failed to initialize trading engine');
      }
    } catch (error) {
      setInitError(error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setIsInitializing(false);
    }
  };

  // Load saved config on mount
  useEffect(() => {
    try {
      const savedConfigStr = localStorage.getItem('tradingConfig');
      if (savedConfigStr) {
        const savedConfig = JSON.parse(savedConfigStr);
        setApiConfig(prev => ({
          ...prev,
          apiKey: savedConfig.apiKey || '',
          apiSecret: savedConfig.apiSecret || '',
          symbol: savedConfig.symbol || 'XRPUSDT',
          leverage: savedConfig.leverage || 5,
          amountUsdt: savedConfig.amountUsdt || 20,
          timeframe: savedConfig.timeframe || '5min'
        }));
      }
    } catch (error) {
      console.error('Error loading saved config:', error);
    }
  }, []);

  const formatNumber = (num: number, decimals: number = 4): string => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(num);
  };

  const formatCurrency = (num: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);
  };

  const formatPercent = (num: number): string => {
    return `${num >= 0 ? '+' : ''}${formatNumber(num, 2)}%`;
  };

  const formatTimestamp = (timestamp: number): string => {
    return new Date(timestamp).toLocaleTimeString('en-US');
  };

  const getChangeColor = (value: number): string => {
    return value >= 0 ? 'text-green-600' : 'text-red-600';
  };

  const getSideColor = (side: string): string => {
    return side.toLowerCase() === 'buy' || side.toLowerCase() === 'long' 
      ? 'bg-green-100 text-green-800' 
      : 'bg-red-100 text-red-800';
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>WebSocket Connection & Subscription Status</span>
            <div className="flex items-center space-x-2">
              <Badge variant={engine?.wsManager?.connected ? "default" : "destructive"}>
                {engine?.wsManager?.connected ? "Connected" : "Disconnected"}
              </Badge>
              <Badge variant={engine?.wsManager?.authenticated ? "default" : "secondary"}>
                {engine?.wsManager?.authenticated ? "Authenticated" : "Not Authenticated"}
              </Badge>
              {!isInitialized && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowConfig(!showConfig)}
                >
                  {showConfig ? "Hide Config" : "Configure API"}
                </Button>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!isInitialized && (
            <Alert className="mb-4">
              <AlertDescription>
                Trading engine is not initialized. Please configure your API settings to connect to CoinEx WebSocket.
              </AlertDescription>
            </Alert>
          )}

          {showConfig && (
            <Card className="mb-4">
              <CardHeader>
                <CardTitle className="text-lg">API Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {initError && (
                  <Alert variant="destructive">
                    <AlertDescription>{initError}</AlertDescription>
                  </Alert>
                )}
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="apiKey">API Key</Label>
                    <Input
                      id="apiKey"
                      type="text"
                      value={apiConfig.apiKey}
                      onChange={(e) => setApiConfig(prev => ({ ...prev, apiKey: e.target.value }))}
                      placeholder="Enter your CoinEx API Key"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="apiSecret">API Secret</Label>
                    <Input
                      id="apiSecret"
                      type="password"
                      value={apiConfig.apiSecret}
                      onChange={(e) => setApiConfig(prev => ({ ...prev, apiSecret: e.target.value }))}
                      placeholder="Enter your CoinEx API Secret"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="symbol">Symbol</Label>
                    <Input
                      id="symbol"
                      type="text"
                      value={apiConfig.symbol}
                      onChange={(e) => setApiConfig(prev => ({ ...prev, symbol: e.target.value }))}
                      placeholder="e.g., XRPUSDT"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="leverage">Leverage</Label>
                    <Input
                      id="leverage"
                      type="number"
                      value={apiConfig.leverage}
                      onChange={(e) => setApiConfig(prev => ({ ...prev, leverage: parseInt(e.target.value) || 1 }))}
                      min="1"
                      max="125"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="amountUsdt">Amount (USDT)</Label>
                    <Input
                      id="amountUsdt"
                      type="number"
                      value={apiConfig.amountUsdt}
                      onChange={(e) => setApiConfig(prev => ({ ...prev, amountUsdt: parseFloat(e.target.value) || 1 }))}
                      min="1"
                      step="0.1"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="timeframe">Timeframe</Label>
                    <select
                      id="timeframe"
                      value={apiConfig.timeframe}
                      onChange={(e) => setApiConfig(prev => ({ ...prev, timeframe: e.target.value }))}
                      className="w-full p-2 border border-gray-300 rounded-md"
                    >
                      <option value="1min">1 Minute</option>
                      <option value="5min">5 Minutes</option>
                      <option value="15min">15 Minutes</option>
                      <option value="30min">30 Minutes</option>
                      <option value="1hour">1 Hour</option>
                      <option value="4hour">4 Hours</option>
                      <option value="1day">1 Day</option>
                    </select>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowConfig(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleInitialize}
                    disabled={isInitializing || !apiConfig.apiKey || !apiConfig.apiSecret}
                  >
                    {isInitializing ? "Initializing..." : "Initialize & Connect"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="font-medium">Last Update:</span>
                <span>{lastUpdate.toLocaleTimeString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Symbol:</span>
                <span>{state.config?.symbol || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Timeframe:</span>
                <span>{state.config?.timeframe || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Current Price:</span>
                <span>{state.currentPrice ? formatCurrency(state.currentPrice) : 'N/A'}</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Data Subscriptions:</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex justify-between">
                  <span>Order Book:</span>
                  <Badge variant={subscriptionStatus.depth ? "default" : "secondary"}>
                    {subscriptionStatus.depth ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Candles:</span>
                  <Badge variant={subscriptionStatus.kline ? "default" : "secondary"}>
                    {subscriptionStatus.kline ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Trades:</span>
                  <Badge variant={subscriptionStatus.trades ? "default" : "secondary"}>
                    {subscriptionStatus.trades ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Market Data:</span>
                  <Badge variant={subscriptionStatus.market ? "default" : "secondary"}>
                    {subscriptionStatus.market ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Ticker:</span>
                  <Badge variant={subscriptionStatus.ticker ? "default" : "secondary"}>
                    {subscriptionStatus.ticker ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Positions:</span>
                  <Badge variant={subscriptionStatus.positions ? "default" : "secondary"}>
                    {subscriptionStatus.positions ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Market State:</span>
                  <Badge variant={subscriptionStatus.state ? "default" : "secondary"}>
                    {subscriptionStatus.state ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Connection Info:</h4>
              <div className="text-sm space-y-1">
                <div>WebSocket URL: wss://socket.coinex.com/v2/futures</div>
                <div>Compression: zlib/gzip</div>
                <div>Authentication: HMAC-SHA256</div>
                <div>Reconnect Attempts: {engine?.wsManager?.reconnectAttempts || 0}</div>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  if (engine?.wsManager && state.config?.symbol) {
                    engine.wsManager.testSubscriptions(state.config.symbol);
                  }
                }}
                className="mt-2"
              >
                Test All Subscriptions
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Market Data */}
      {marketData && (
        <Card>
          <CardHeader>
            <CardTitle>Market Data (Real-time)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Symbol:</span>
                  <span>{marketData.symbol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Last Price:</span>
                  <span className={getChangeColor(marketData.change24h)}>
                    {formatCurrency(marketData.lastPrice)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Bid:</span>
                  <span>{formatCurrency(marketData.bid)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Ask:</span>
                  <span>{formatCurrency(marketData.ask)}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">24h High:</span>
                  <span>{formatCurrency(marketData.high24h)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">24h Low:</span>
                  <span>{formatCurrency(marketData.low24h)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">24h Volume:</span>
                  <span>{formatNumber(marketData.volume24h, 2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">24h Change:</span>
                  <span className={getChangeColor(marketData.change24h)}>
                    {formatCurrency(marketData.change24h)} ({formatPercent(marketData.changePercent24h)})
                  </span>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Spread:</span>
                  <span>{formatCurrency(marketData.ask - marketData.bid)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Mid Price:</span>
                  <span>{formatCurrency((marketData.bid + marketData.ask) / 2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Update Time:</span>
                  <span>{formatTimestamp(lastUpdate.getTime())}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Current Candle */}
      {currentCandle && (
        <Card>
          <CardHeader>
            <CardTitle>Current Candle (Real-time)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <div className="space-y-1">
                <div className="text-sm font-medium">Open</div>
                <div className={getChangeColor(currentCandle.close - currentCandle.open)}>
                  {formatCurrency(currentCandle.open)}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-sm font-medium">High</div>
                <div className="text-green-600">
                  {formatCurrency(currentCandle.high)}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-sm font-medium">Low</div>
                <div className="text-red-600">
                  {formatCurrency(currentCandle.low)}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-sm font-medium">Close</div>
                <div className={getChangeColor(currentCandle.close - currentCandle.open)}>
                  {formatCurrency(currentCandle.close)}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-sm font-medium">Volume</div>
                <div>
                  {formatNumber(currentCandle.volume, 2)}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-sm font-medium">Change</div>
                <div className={getChangeColor(currentCandle.close - currentCandle.open)}>
                  {formatCurrency(currentCandle.close - currentCandle.open)} ({formatPercent(((currentCandle.close - currentCandle.open) / currentCandle.open) * 100)})
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Market State (24h Status) */}
      {marketStateData && (
        <Card>
          <CardHeader>
            <CardTitle>Market Status (24h)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Market:</span>
                  <span>{marketStateData.market}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Last Price:</span>
                  <span>{formatCurrency(parseFloat(marketStateData.last))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Open Price:</span>
                  <span>{formatCurrency(parseFloat(marketStateData.open))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Close Price:</span>
                  <span>{formatCurrency(parseFloat(marketStateData.close))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Mark Price:</span>
                  <span>{formatCurrency(parseFloat(marketStateData.mark_price))}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">24h High:</span>
                  <span className="text-green-600">{formatCurrency(parseFloat(marketStateData.high))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">24h Low:</span>
                  <span className="text-red-600">{formatCurrency(parseFloat(marketStateData.low))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">24h Volume:</span>
                  <span>{formatNumber(parseFloat(marketStateData.volume), 2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">24h Value:</span>
                  <span>{formatNumber(parseFloat(marketStateData.value), 2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Open Interest:</span>
                  <span>{formatNumber(parseFloat(marketStateData.open_interest_size), 2)}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Index Price:</span>
                  <span>{formatCurrency(parseFloat(marketStateData.index_price))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Volume Buy:</span>
                  <span>{formatNumber(parseFloat(marketStateData.volume_buy), 2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Volume Sell:</span>
                  <span>{formatNumber(parseFloat(marketStateData.volume_sell), 2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Latest Funding Rate:</span>
                  <span className={parseFloat(marketStateData.latest_funding_rate) >= 0 ? 'text-green-600' : 'text-red-600'}>
                    {formatPercent(parseFloat(marketStateData.latest_funding_rate) * 100)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Next Funding Rate:</span>
                  <span className={parseFloat(marketStateData.next_funding_rate) >= 0 ? 'text-green-600' : 'text-red-600'}>
                    {formatPercent(parseFloat(marketStateData.next_funding_rate) * 100)}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <div className="text-sm text-gray-600">
                <div><strong>Period:</strong> {marketStateData.period / 3600} hours</div>
                <div><strong>Latest Funding Time:</strong> {new Date(marketStateData.latest_funding_time).toLocaleString()}</div>
                <div><strong>Next Funding Time:</strong> {new Date(marketStateData.next_funding_time).toLocaleString()}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Trades */}
      {recentTrades.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Trades (Real-time)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {recentTrades.map((trade, index) => (
                <div key={index} className="flex items-center justify-between p-2 border rounded">
                  <div className="flex items-center space-x-2">
                    <Badge className={getSideColor(trade.side)}>
                      {trade.side.toUpperCase()}
                    </Badge>
                    <span className="text-sm text-gray-500">
                      {formatTimestamp(trade.timestamp)}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{formatCurrency(trade.price)}</div>
                    <div className="text-sm text-gray-500">{formatNumber(trade.amount, 4)}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Positions */}
      {positions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Active Positions (Real-time)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {positions.map((position, index) => (
                <div key={position.id} className="border rounded-lg p-4 space-y-4">
                  {/* Position Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge className={getSideColor(position.side)}>
                        {position.side.toUpperCase()}
                      </Badge>
                      <span className="font-medium">{position.market}</span>
                      <Badge variant="outline">
                        {position.margin_mode} {position.leverage}x
                      </Badge>
                    </div>
                    <div className="text-right">
                      <div className={`font-medium ${getChangeColor(position.unrealized_pnl)}`}>
                        PnL: {formatCurrency(position.unrealized_pnl)}
                      </div>
                      <div className="text-sm text-gray-500">
                        Realized: {formatCurrency(position.realized_pnl)}
                      </div>
                    </div>
                  </div>

                  {/* Position Details Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Position Size:</span>
                        <span>{formatNumber(position.ath_position_amount, 4)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Position Value:</span>
                        <span>{formatCurrency(position.amount_usdt)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Entry Price:</span>
                        <span>{formatCurrency(position.avg_entry_price)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Current Price:</span>
                        <span>{formatCurrency(position.settle_price)}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Take Profit:</span>
                        <span>
                          {position.take_profit_price 
                            ? formatCurrency(parseFloat(position.take_profit_price))
                            : 'Not Set'}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Stop Loss:</span>
                        <span>
                          {position.stop_loss_price
                            ? formatCurrency(parseFloat(position.stop_loss_price))
                            : 'Not Set'}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Liquidation Price:</span>
                        <span>
                          {position.liq_price
                            ? formatCurrency(position.liq_price)
                            : 'N/A'}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Margin Ratio:</span>
                        <span>{formatNumber(position.margin_ratio * 100, 2)}%</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Open Interest:</span>
                        <span>{formatNumber(position.open_interest || 0, 4)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Available Margin:</span>
                        <span>{formatCurrency(position.margin_avbl || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Maintenance Margin:</span>
                        <span>{formatCurrency(position.maintenance_margin_value || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>ADL Level:</span>
                        <span>{position.adl_level || 'N/A'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* No Data Message */}
      {!marketData && !currentCandle && positions.length === 0 && recentTrades.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-500">No WebSocket data available. Please ensure the trading engine is connected and authenticated.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}