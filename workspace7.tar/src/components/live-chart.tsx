'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, ComposedChart, ScatterChart, Scatter, ZAxis } from 'recharts'
import { 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  Activity,
  BarChart3,
  LineChart as LineChartIcon,
  BarChart2,
  CandlestickChart as CandlestickIcon,
  Clock
} from 'lucide-react'
import { AVAILABLE_TIMEFRAMES } from '@/lib/coinex-timeframes'

interface CandleData {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

interface MarketData {
  symbol: string
  price: number
  change24h: number
  volume24h: number
  high24h: number
  low24h: number
}

interface LiveChartProps {
  data: CandleData[]
  marketData: MarketData | null
  onTimeframeChange: (timeframe: string) => void
  onSymbolChange: (symbol: string) => void
  currentTimeframe: string
  currentSymbol: string
  isConnected: boolean
  lastUpdate: Date | null
}

interface CustomTooltipProps {
  active?: boolean
  payload?: any[]
  label?: string
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-background border rounded-lg p-3 shadow-lg">
        <p className="font-medium">{new Date(data.timestamp).toLocaleString()}</p>
        <div className="space-y-1 text-sm">
          <div className="flex justify-between gap-4">
            <span>Open:</span>
            <span className="font-mono">{data.open.toFixed(4)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>High:</span>
            <span className="font-mono text-green-600">{data.high.toFixed(4)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Low:</span>
            <span className="font-mono text-red-600">{data.low.toFixed(4)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Close:</span>
            <span className={`font-mono ${data.close >= data.open ? 'text-green-600' : 'text-red-600'}`}>
              {data.close.toFixed(4)}
            </span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Volume:</span>
            <span className="font-mono">{data.volume.toLocaleString()}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
}

export function LiveChart({ 
  data, 
  marketData, 
  onTimeframeChange, 
  onSymbolChange, 
  currentTimeframe, 
  currentSymbol, 
  isConnected, 
  lastUpdate 
}: LiveChartProps) {
  const [chartType, setChartType] = useState<'line' | 'area' | 'candlestick'>('candlestick')
  const [volumeData, setVolumeData] = useState<any[]>([])

  useEffect(() => {
    // Prepare volume data for display
    const volumeChartData = data.map(candle => ({
      time: new Date(candle.timestamp).toLocaleTimeString(),
      volume: candle.volume,
      price: candle.close
    }))
    setVolumeData(volumeChartData)
  }, [data])

  const formatChartData = () => {
    return data.map(candle => ({
      time: new Date(candle.timestamp).toLocaleTimeString(),
      timestamp: candle.timestamp,
      open: candle.open,
      high: candle.high,
      low: candle.low,
      close: candle.close,
      volume: candle.volume
    }))
  }

  const chartData = formatChartData()

  const renderChart = () => {
    switch (chartType) {
      case 'line':
        return (
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis 
              dataKey="time" 
              tick={{ fontSize: 12 }}
              interval="preserveStartEnd"
            />
            <YAxis 
              domain={['dataMin - 0.005', 'dataMax + 0.005']}
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => value.toFixed(4)}
            />
            <Tooltip content={<CustomTooltip />} />
            <Line 
              type="monotone" 
              dataKey="close" 
              stroke="#3b82f6" 
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4 }}
            />
          </LineChart>
        )

      case 'area':
        return (
          <AreaChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis 
              dataKey="time" 
              tick={{ fontSize: 12 }}
              interval="preserveStartEnd"
            />
            <YAxis 
              domain={['dataMin - 0.005', 'dataMax + 0.005']}
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => value.toFixed(4)}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area 
              type="monotone" 
              dataKey="close" 
              stroke="#3b82f6" 
              fill="#3b82f6" 
              fillOpacity={0.2}
              strokeWidth={2}
            />
          </AreaChart>
        )

      case 'candlestick':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 12 }}
                interval="preserveStartEnd"
              />
              <YAxis 
                domain={['dataMin - 0.005', 'dataMax + 0.005']}
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => value.toFixed(4)}
              />
              <Tooltip content={<CustomTooltip />} />
              {/* Close price line */}
              <Line 
                type="monotone" 
                dataKey="close" 
                stroke="#3b82f6" 
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
              {/* High price line */}
              <Line 
                type="monotone" 
                dataKey="high" 
                stroke="#10b981" 
                strokeWidth={1}
                dot={false}
                activeDot={false}
                strokeDasharray="5 5"
              />
              {/* Low price line */}
              <Line 
                type="monotone" 
                dataKey="low" 
                stroke="#ef4444" 
                strokeWidth={1}
                dot={false}
                activeDot={false}
                strokeDasharray="5 5"
              />
            </LineChart>
          </ResponsiveContainer>
        )

      default:
        return null
    }
  }

  const getLastCandleStatus = () => {
    if (data.length === 0) return null
    const lastCandle = data[data.length - 1]
    const isBullish = lastCandle.close >= lastCandle.open
    
    return (
      <div className="flex items-center gap-2">
        {isBullish ? (
          <TrendingUp className="h-4 w-4 text-green-600" />
        ) : (
          <TrendingDown className="h-4 w-4 text-red-600" />
        )}
        <span className={`text-sm font-medium ${isBullish ? 'text-green-600' : 'text-red-600'}`}>
          {isBullish ? 'Bullish' : 'Bearish'}
        </span>
        <span className="text-sm text-muted-foreground">
          O: {lastCandle.open.toFixed(4)} H: {lastCandle.high.toFixed(4)} L: {lastCandle.low.toFixed(4)} C: {lastCandle.close.toFixed(4)}
        </span>
      </div>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Live Chart {currentSymbol}
              <Badge variant={isConnected ? "default" : "destructive"}>
                {isConnected ? 'Live' : 'Offline'}
              </Badge>
            </CardTitle>
            <CardDescription>
              {marketData && (
                <div className="flex items-center gap-4 mt-2">
                  <span className="font-mono text-lg">
                    {marketData.price.toFixed(4)}
                  </span>
                  <Badge variant={marketData.change24h >= 0 ? "default" : "destructive"}>
                    {marketData.change24h >= 0 ? '+' : ''}{marketData.change24h.toFixed(2)}%
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    Volume: {marketData.volume24h.toLocaleString()}
                  </span>
                  {lastUpdate && (
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {lastUpdate.toLocaleTimeString()}
                    </div>
                  )}
                </div>
              )}
            </CardDescription>
          </div>
          
          <div className="flex items-center gap-2">
            <Select value={currentSymbol} onValueChange={onSymbolChange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BTCUSDT">BTC/USDT</SelectItem>
                <SelectItem value="ETHUSDT">ETH/USDT</SelectItem>
                <SelectItem value="XRPUSDT">XRP/USDT</SelectItem>
                <SelectItem value="ADAUSDT">ADA/USDT</SelectItem>
                <SelectItem value="DOTUSDT">DOT/USDT</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={currentTimeframe} onValueChange={onTimeframeChange}>
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {AVAILABLE_TIMEFRAMES.map(tf => (
                  <SelectItem key={tf.value} value={tf.value}>
                    {tf.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="flex rounded-md border">
              <Button
                variant={chartType === 'line' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setChartType('line')}
                className="rounded-r-none"
              >
                <LineChartIcon className="h-4 w-4" />
              </Button>
              <Button
                variant={chartType === 'area' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setChartType('area')}
                className="rounded-none border-x"
              >
                <TrendingUp className="h-4 w-4" />
              </Button>
              <Button
                variant={chartType === 'candlestick' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setChartType('candlestick')}
                className="rounded-l-none"
              >
                <CandlestickIcon className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Last candle status */}
        <div className="mb-4 p-3 bg-muted/50 rounded-lg">
          {getLastCandleStatus()}
        </div>
        
        {/* Main chart */}
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            {renderChart()}
          </ResponsiveContainer>
        </div>
        
        {/* Volume chart */}
        <div className="mt-6">
          <h4 className="text-sm font-medium mb-2">Volume</h4>
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={volumeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Bar 
                  dataKey="volume" 
                  fill="#6366f1"
                  opacity={0.7}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Market info */}
        {marketData && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground">24h High</div>
              <div className="font-mono font-medium">{marketData.high24h.toFixed(4)}</div>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground">24h Low</div>
              <div className="font-mono font-medium">{marketData.low24h.toFixed(4)}</div>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground">24h Change</div>
              <div className={`font-mono font-medium ${marketData.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {marketData.change24h >= 0 ? '+' : ''}{marketData.change24h.toFixed(2)}%
              </div>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground">24h Volume</div>
              <div className="font-mono font-medium">{marketData.volume24h.toLocaleString()}</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}