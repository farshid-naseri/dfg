'use client'

import React, { memo, useEffect, useRef, useState } from 'react'
import dynamic from 'next/dynamic'

// Dynamic import for ApexCharts to avoid SSR issues
const ReactApexChart = dynamic(() => import('react-apexcharts'), { 
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
      <p className="text-muted-foreground">در حال بارگذاری کتابخانه نمودار...</p>
    </div>
  )
})

interface CandleChartProps {
  options: any
  series: any[]
  height: number
  onChartReady?: (chart: any) => void
}

const CandleChart: React.FC<CandleChartProps> = memo(({ options, series, height, onChartReady }) => {
  const chartRef = useRef<any>(null)
  const isInitialized = useRef(false)
  const [currentSeries, setCurrentSeries] = useState(series)

  useEffect(() => {
    // به‌روزرسانی سریس‌ها فقط زمانی که واقعاً تغییر کرده‌اند
    if (JSON.stringify(series) !== JSON.stringify(currentSeries)) {
      setCurrentSeries(series)
      
      // اگر نمودار از قبل مقداردهی شده، از به‌روزرسانی هوشمند استفاده کن
      if (chartRef.current && chartRef.current.chart && isInitialized.current) {
        try {
          chartRef.current.chart.updateSeries(series, false)
        } catch (error) {
          console.error('Error updating chart series:', error)
        }
      }
    }
  }, [series, currentSeries])

  useEffect(() => {
    if (chartRef.current && !isInitialized.current) {
      isInitialized.current = true
      if (onChartReady) {
        onChartReady(chartRef.current)
      }
    }
  }, [onChartReady])

  return (
    <ReactApexChart
      ref={chartRef}
      options={options}
      series={currentSeries}
      type="candlestick"
      height={height}
    />
  )
})

CandleChart.displayName = 'CandleChart'

export default CandleChart