"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from "recharts";
import { 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  Activity,
  BarChart3,
  LineChart as LineChartIcon,
  BarChart2
} from "lucide-react";

interface CandleData {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface MarketData {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  high24h: number;
  low24h: number;
}

interface ChartProps {
  data: CandleData[];
  marketData: MarketData | null;
  onRefresh: () => void;
  loading: boolean;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-background border rounded-lg p-3 shadow-lg">
        <p className="font-medium">{label}</p>
        <div className="space-y-1 text-sm">
          <div className="flex justify-between gap-4">
            <span>Open:</span>
            <span className="font-mono">{data.open.toFixed(4)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>High:</span>
            <span className="font-mono text-green-600">{data.high.toFixed(4)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Low:</span>
            <span className="font-mono text-red-600">{data.low.toFixed(4)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Close:</span>
            <span className={`font-mono ${data.close >= data.open ? 'text-green-600' : 'text-red-600'}`}>
              {data.close.toFixed(4)}
            </span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Volume:</span>
            <span className="font-mono">{data.volume.toLocaleString()}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
}

export function MarketChart({ data, marketData, onRefresh, loading }: ChartProps) {
  const [chartType, setChartType] = useState<'line' | 'candlestick' | 'area'>('line');
  const [timeframe, setTimeframe] = useState('5min');
  const [volumeData, setVolumeData] = useState<any[]>([]);

  useEffect(() => {
    // آماده‌سازی داده‌های حجم برای نمایش
    const volumeChartData = data.map(candle => ({
      time: new Date(candle.timestamp).toLocaleTimeString(),
      volume: candle.volume,
      price: candle.close
    }));
    setVolumeData(volumeChartData);
  }, [data]);

  const formatChartData = () => {
    return data.map(candle => ({
      time: new Date(candle.timestamp).toLocaleTimeString(),
      open: candle.open,
      high: candle.high,
      low: candle.low,
      close: candle.close,
      volume: candle.volume
    }));
  };

  const chartData = formatChartData();

  const renderChart = () => {
    switch (chartType) {
      case 'line':
        return (
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis 
              dataKey="time" 
              tick={{ fontSize: 12 }}
              interval="preserveStartEnd"
            />
            <YAxis 
              domain={['dataMin - 0.005', 'dataMax + 0.005']}
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => value.toFixed(4)}
            />
            <Tooltip content={<CustomTooltip />} />
            <Line 
              type="monotone" 
              dataKey="close" 
              stroke="#3b82f6" 
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4 }}
            />
          </LineChart>
        );

      case 'area':
        return (
          <AreaChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis 
              dataKey="time" 
              tick={{ fontSize: 12 }}
              interval="preserveStartEnd"
            />
            <YAxis 
              domain={['dataMin - 0.005', 'dataMax + 0.005']}
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => value.toFixed(4)}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area 
              type="monotone" 
              dataKey="close" 
              stroke="#3b82f6" 
              fill="#3b82f6" 
              fillOpacity={0.2}
              strokeWidth={2}
            />
          </AreaChart>
        );

      case 'candlestick':
        return (
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis 
              dataKey="time" 
              tick={{ fontSize: 12 }}
              interval="preserveStartEnd"
            />
            <YAxis 
              domain={['dataMin - 0.005', 'dataMax + 0.005']}
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => value.toFixed(4)}
            />
            <Tooltip content={<CustomTooltip />} />
            {/* نمایش کندل‌ها به صورت خطوط بالا و پایین */}
            <Line 
              type="monotone" 
              dataKey="high" 
              stroke="#10b981" 
              strokeWidth={1}
              dot={false}
              connectNulls={false}
            />
            <Line 
              type="monotone" 
              dataKey="low" 
              stroke="#ef4444" 
              strokeWidth={1}
              dot={false}
              connectNulls={false}
            />
            <Line 
              type="monotone" 
              dataKey="close" 
              stroke="#3b82f6" 
              strokeWidth={2}
              dot={false}
            />
            {/* نمایش خطوط باز و بسته شدن */}
            <Line 
              type="monotone" 
              dataKey="open" 
              stroke="#f59e0b" 
              strokeWidth={1}
              dot={false}
              strokeDasharray="5 5"
            />
          </LineChart>
        );

      default:
        return null;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              نمودار {marketData?.symbol || 'BTCUSDT'}
            </CardTitle>
            <CardDescription>
              {marketData && (
                <div className="flex items-center gap-4 mt-2">
                  <span className="font-mono text-lg">
                    {marketData.price.toFixed(4)}
                  </span>
                  <Badge variant={marketData.change24h >= 0 ? "default" : "destructive"}>
                    {marketData.change24h >= 0 ? '+' : ''}{marketData.change24h.toFixed(2)}%
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    حجم: {marketData.volume24h.toLocaleString()}
                  </span>
                </div>
              )}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1min">1 دقیقه</SelectItem>
                <SelectItem value="5min">5 دقیقه</SelectItem>
                <SelectItem value="15min">15 دقیقه</SelectItem>
                <SelectItem value="30min">30 دقیقه</SelectItem>
                <SelectItem value="1hour">1 ساعت</SelectItem>
                <SelectItem value="4hour">4 ساعت</SelectItem>
                <SelectItem value="1day">1 روز</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex rounded-md border">
              <Button
                variant={chartType === 'line' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setChartType('line')}
                className="rounded-r-none"
              >
                <LineChartIcon className="h-4 w-4" />
              </Button>
              <Button
                variant={chartType === 'area' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setChartType('area')}
                className="rounded-none border-x"
              >
                <TrendingUp className="h-4 w-4" />
              </Button>
              <Button
                variant={chartType === 'candlestick' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setChartType('candlestick')}
                className="rounded-l-none"
              >
                <BarChart2 className="h-4 w-4" />
              </Button>
            </div>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onRefresh}
              disabled={loading}
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            {renderChart()}
          </ResponsiveContainer>
        </div>
        
        {/* نمودار حجم */}
        <div className="mt-6">
          <h4 className="text-sm font-medium mb-2">حجم معاملات</h4>
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={volumeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Bar 
                  dataKey="volume" 
                  fill="#6366f1"
                  opacity={0.7}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* اطلاعات بازار */}
        {marketData && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground">بالاترین 24h</div>
              <div className="font-mono font-medium">{marketData.high24h.toFixed(4)}</div>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground">پایین‌ترین 24h</div>
              <div className="font-mono font-medium">{marketData.low24h.toFixed(4)}</div>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground">تغییر 24h</div>
              <div className={`font-mono font-medium ${marketData.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {marketData.change24h >= 0 ? '+' : ''}{marketData.change24h.toFixed(2)}%
              </div>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground">حجم 24h</div>
              <div className="font-mono font-medium">{marketData.volume24h.toLocaleString()}</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// کامپوننت نمایش چندین نمودار در تب‌های مختلف
export function MultiChartDashboard({ data, marketData, onRefresh, loading }: ChartProps) {
  return (
    <Tabs defaultValue="price" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="price">نمودار قیمت</TabsTrigger>
        <TabsTrigger value="volume">حجم معاملات</TabsTrigger>
        <TabsTrigger value="analysis">تحلیل تکنیکال</TabsTrigger>
      </TabsList>
      
      <TabsContent value="price" className="space-y-4">
        <MarketChart 
          data={data} 
          marketData={marketData} 
          onRefresh={onRefresh} 
          loading={loading} 
        />
      </TabsContent>
      
      <TabsContent value="volume" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>تحلیل حجم معاملات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.map(candle => ({
                  time: new Date(candle.timestamp).toLocaleTimeString(),
                  volume: candle.volume,
                  price: candle.close
                }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="volume" fill="#6366f1" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
      
      <TabsContent value="analysis" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>شاخص‌های تکنیکال</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>RSI (14)</span>
                  <Badge variant="outline">65.4</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>MACD</span>
                  <Badge variant="outline">0.0023</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>ATR</span>
                  <Badge variant="outline">0.0045</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>SuperTrend</span>
                  <Badge variant="default">صعودی</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>سطوح حمایت و مقاومت</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">مقاومت</div>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="font-mono">R3</span>
                      <span className="font-mono">0.5350</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">R2</span>
                      <span className="font-mono">0.5320</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">R1</span>
                      <span className="font-mono">0.5290</span>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">حمایت</div>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="font-mono">S1</span>
                      <span className="font-mono">0.5230</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">S2</span>
                      <span className="font-mono">0.5200</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">S3</span>
                      <span className="font-mono">0.5170</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>
    </Tabs>
  );
}