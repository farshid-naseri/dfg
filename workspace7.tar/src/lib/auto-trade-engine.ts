import { strategyManager, StrategyManager } from './strategies/strategy-manager';
import { StrategySignal, CandleData } from './strategies/strategy';
import { TradingEngine } from './trading-engine';
import { EventEmitter } from 'events';

// 自动交易配置接口
export interface AutoTradeConfig {
  symbol: string;
  timeframe: string;
  amount: number;
  leverage: number;
  marginMode: 'cross' | 'isolated';
  takeProfitPercent: number;
  stopLossPercent: number;
  strategy: string;
  strategyParams: Record<string, any>;
}

// 信号日志接口
export interface SignalLog {
  id: string;
  timestamp: number;
  strategy: string;
  signalType: 'buy' | 'sell';
  price: number;
  executed: boolean;
  orderId?: string;
  error?: string;
}

export class AutoTradeEngine extends EventEmitter {
  private tradingEngine: TradingEngine;
  private strategyManager: StrategyManager;
  private isActive: boolean = false;
  private config: AutoTradeConfig | null = null;
  private candleBuffer: CandleData[] = [];
  private maxBufferSize: number = 100;
  private signalLogs: SignalLog[] = [];
  private lastCandleTime: number = 0;
  private checkInterval: NodeJS.Timeout | null = null;

  constructor(tradingEngine: TradingEngine) {
    super();
    this.tradingEngine = tradingEngine;
    this.strategyManager = strategyManager;
  }

  // 启动自动交易
  public start(config: AutoTradeConfig): boolean {
    if (this.isActive) {
      this.emit('error', new Error('Auto trade is already active'));
      return false;
    }

    try {
      // 验证配置
      if (!this.validateConfig(config)) {
        this.emit('error', new Error('Invalid auto trade configuration'));
        return false;
      }

      // 激活策略
      if (!this.strategyManager.activateStrategy(config.strategy, config.strategyParams)) {
        this.emit('error', new Error(`Failed to activate strategy: ${config.strategy}`));
        return false;
      }

      this.config = config;
      this.isActive = true;
      this.candleBuffer = [];
      this.signalLogs = [];
      this.lastCandleTime = 0;

      // 启动检查间隔
      this.startCheckInterval();

      this.emit('started', config);
      return true;
    } catch (error) {
      this.emit('error', error);
      return false;
    }
  }

  // 停止自动交易
  public stop(): void {
    if (!this.isActive) {
      return;
    }

    this.isActive = false;
    this.config = null;

    // 停止检查间隔
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }

    // 停用策略
    this.strategyManager.deactivateStrategy();

    this.emit('stopped');
  }

  // 更新K线数据
  public updateCandleData(candle: CandleData): void {
    if (!this.isActive || !this.config) {
      return;
    }

    // 添加到缓冲区
    this.candleBuffer.push(candle);

    // 保持缓冲区大小
    if (this.candleBuffer.length > this.maxBufferSize) {
      this.candleBuffer.shift();
    }

    // 检查是否需要执行策略（在新K线开始时）
    const candleTime = Math.floor(candle.timestamp / (this.getTimeframeSeconds() * 1000)) * (this.getTimeframeSeconds() * 1000);
    
    if (candleTime !== this.lastCandleTime && this.candleBuffer.length >= 2) {
      this.lastCandleTime = candleTime;
      
      // 延迟执行，确保K线完全关闭
      setTimeout(() => {
        this.executeStrategy();
      }, 100);
    }
  }

  // 批量更新K线数据（用于初始化）
  public updateCandleBatch(candles: CandleData[]): void {
    if (!this.isActive || !this.config) {
      return;
    }

    // 添加到缓冲区
    this.candleBuffer.push(...candles);

    // 保持缓冲区大小，只保留最新的100根K线
    if (this.candleBuffer.length > this.maxBufferSize) {
      this.candleBuffer = this.candleBuffer.slice(-this.maxBufferSize);
    }

    // 更新最后K线时间
    if (this.candleBuffer.length > 0) {
      const lastCandle = this.candleBuffer[this.candleBuffer.length - 1];
      this.lastCandleTime = Math.floor(lastCandle.timestamp / (this.getTimeframeSeconds() * 1000)) * (this.getTimeframeSeconds() * 1000);
    }
  }

  // 获取信号日志
  public getSignalLogs(): SignalLog[] {
    return [...this.signalLogs];
  }

  // 清除信号日志
  public clearSignalLogs(): void {
    this.signalLogs = [];
  }

  // 获取当前状态
  public getStatus(): {
    isActive: boolean;
    config: AutoTradeConfig | null;
    bufferSize: number;
    lastSignalTime: number | null;
  } {
    const lastSignal = this.signalLogs[this.signalLogs.length - 1];
    return {
      isActive: this.isActive,
      config: this.config,
      bufferSize: this.candleBuffer.length,
      lastSignalTime: lastSignal ? lastSignal.timestamp : null
    };
  }

  // 验证配置
  private validateConfig(config: AutoTradeConfig): boolean {
    return !!(
      config.symbol &&
      config.timeframe &&
      config.amount > 0 &&
      config.leverage > 0 &&
      config.marginMode &&
      config.takeProfitPercent >= 0 &&
      config.stopLossPercent >= 0 &&
      config.strategy &&
      this.strategyManager.getStrategy(config.strategy)
    );
  }

  // 获取时间框架秒数
  private getTimeframeSeconds(): number {
    if (!this.config) return 60;

    const timeframeMap: Record<string, number> = {
      '1m': 60,
      '3m': 180,
      '5m': 300,
      '15m': 900,
      '30m': 1800,
      '1h': 3600,
      '2h': 7200,
      '4h': 14400,
      '6h': 21600,
      '12h': 43200,
      '1d': 86400,
      '3d': 259200,
      '1w': 604800
    };

    return timeframeMap[this.config.timeframe] || 60;
  }

  // 启动检查间隔
  private startCheckInterval(): void {
    // 每5秒检查一次状态
    this.checkInterval = setInterval(() => {
      if (this.isActive) {
        this.emit('statusUpdate', this.getStatus());
      }
    }, 5000);
  }

  // 执行策略
  private async executeStrategy(): Promise<void> {
    if (!this.isActive || !this.config || this.candleBuffer.length < 2) {
      return;
    }

    try {
      // 计算策略信号
      const result = this.strategyManager.calculateSignals(this.candleBuffer);
      
      if (!result || !result.signals || result.signals.length === 0) {
        return;
      }

      // 获取最新的信号
      const latestSignal = result.signals[result.signals.length - 1];
      
      // 检查是否已经处理过这个信号
      const signalId = `${latestSignal.timestamp}_${latestSignal.type}`;
      const existingSignal = this.signalLogs.find(log => log.id === signalId);
      
      if (existingSignal) {
        return;
      }

      // 记录信号
      const signalLog: SignalLog = {
        id: signalId,
        timestamp: latestSignal.timestamp,
        strategy: this.config.strategy,
        signalType: latestSignal.type,
        price: latestSignal.price,
        executed: false
      };

      this.signalLogs.push(signalLog);
      this.emit('signal', signalLog);

      // 执行交易
      await this.executeTrade(signalLog);

    } catch (error) {
      this.emit('error', error);
    }
  }

  // 执行交易
  private async executeTrade(signalLog: SignalLog): Promise<void> {
    if (!this.config) {
      return;
    }

    try {
      // 准备交易参数
      const tradeParams = {
        symbol: this.config.symbol,
        side: signalLog.signalType,
        type: 'market' as const,
        amount: this.config.amount,
        leverage: this.config.leverage,
        marginMode: this.config.marginMode,
        takeProfitPercent: this.config.takeProfitPercent,
        stopLossPercent: this.config.stopLossPercent
      };

      // 执行交易
      const result = await this.tradingEngine.executeManualTrade(tradeParams);

      if (result.success) {
        signalLog.executed = true;
        signalLog.orderId = result.orderId;
        this.emit('tradeExecuted', { signalLog, result });
      } else {
        signalLog.error = result.error;
        this.emit('tradeError', { signalLog, error: result.error });
      }

    } catch (error) {
      signalLog.error = error instanceof Error ? error.message : 'Unknown error';
      this.emit('tradeError', { signalLog, error });
    }
  }
}