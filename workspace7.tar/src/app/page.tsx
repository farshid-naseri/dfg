'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import { TradingDashboard } from '@/components/trading-dashboard'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Settings, Key, Shield, CheckCircle, XCircle, Loader2, Code } from 'lucide-react'


interface MarketData {
  symbol: string
  bid: number
  ask: number
  lastPrice: number
  volume: number
  change24h: number
  changePercent24h: number
  high24h: number
  low24h: number
}

interface CandleData {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

interface OrderBookItem {
  price: number
  amount: number
  total: number
}

interface ApiConfig {
  apiKey: string
  apiSecret: string
  useProxy: boolean
}

export default function Home() {
  const [marketData, setMarketData] = useState<MarketData>({
    symbol: 'BTCUSDT',
    bid: 0,
    ask: 0,
    lastPrice: 0,
    volume: 0,
    change24h: 0,
    changePercent24h: 0,
    high24h: 0,
    low24h: 0
  })

  const [candleData, setCandleData] = useState<CandleData[]>([])
  const [orderBook, setOrderBook] = useState<{
    bids: OrderBookItem[]
    asks: OrderBookItem[]
  }>({
    bids: [],
    asks: []
  })
  const [isConnected, setIsConnected] = useState(false)
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT')
  const [selectedTimeframe, setSelectedTimeframe] = useState('5m')
  const [showApiSettings, setShowApiSettings] = useState(true)
  const [apiConfig, setApiConfig] = useState<ApiConfig | null>(null)
  
  // API Settings state
  const [apiKey, setApiKey] = useState('')
  const [apiSecret, setApiSecret] = useState('')
  const [useProxy, setUseProxy] = useState(true)
  const [showSecret, setShowSecret] = useState(false)
  const [isTesting, setIsTesting] = useState(false)

  // Clean up potentially corrupted localStorage data on mount
  useEffect(() => {
    try {
      console.log('[Home] Checking localStorage on app initialization...');
      // Simple localStorage check without cleanup
      const testKey = 'test_storage';
      localStorage.setItem(testKey, 'test');
      localStorage.removeItem(testKey);
      console.log('[Home] localStorage is working correctly');
    } catch (error) {
      console.error('Error during localStorage check:', error);
    }
  }, [])

  // شبیه‌سازی داده‌های بازار - استفاده از داده‌های واقعی در صورت وجود
  useEffect(() => {
    if (showApiSettings) return // اگر تنظیمات API نمایش داده می‌شود، داده‌ها را تولید نکن

    // اگر API تنظیم شده باشد، از داده‌های واقعی استفاده کن
    if (apiConfig) {
      // در اینجا می‌توانید اتصال WebSocket واقعی را برقرار کنید
      // برای حال حاضر، همچنان از داده‌های شبیه‌سازی شده استفاده می‌کنیم
      console.log('Using real API config:', apiConfig)
    }

    const generateMockData = () => {
      const basePrice = 45000 + Math.random() * 5000
      const spread = basePrice * 0.001
      
      const newMarketData: MarketData = {
        symbol: selectedSymbol,
        bid: basePrice - spread,
        ask: basePrice + spread,
        lastPrice: basePrice,
        volume: 1000000 + Math.random() * 500000,
        change24h: (Math.random() - 0.5) * 2000,
        changePercent24h: (Math.random() - 0.5) * 5,
        high24h: basePrice + Math.random() * 1000,
        low24h: basePrice - Math.random() * 1000
      }

      setMarketData(newMarketData)

      // تولید داده‌های کندل
      const newCandleData: CandleData[] = []
      const now = Math.floor(Date.now() / 1000)
      const timeframeSeconds = selectedTimeframe === '1m' ? 60 : 
                              selectedTimeframe === '5m' ? 300 :
                              selectedTimeframe === '15m' ? 900 :
                              selectedTimeframe === '1h' ? 3600 :
                              selectedTimeframe === '4h' ? 14400 : 86400

      for (let i = 50; i >= 0; i--) {
        const timestamp = now - (i * timeframeSeconds)
        const open = basePrice + (Math.random() - 0.5) * 100
        const close = open + (Math.random() - 0.5) * 50
        const high = Math.max(open, close) + Math.random() * 30
        const low = Math.min(open, close) - Math.random() * 30
        
        newCandleData.push({
          timestamp,
          open,
          high,
          low,
          close,
          volume: 10000 + Math.random() * 50000
        })
      }

      setCandleData(newCandleData)

      // تولید داده‌های دفتر سفارشات
      const bids: OrderBookItem[] = []
      const asks: OrderBookItem[] = []

      for (let i = 0; i < 15; i++) {
        const bidPrice = basePrice - (i * spread * 0.1)
        const askPrice = basePrice + (i * spread * 0.1)
        const bidAmount = Math.random() * 10
        const askAmount = Math.random() * 10

        bids.push({
          price: bidPrice,
          amount: bidAmount,
          total: bidPrice * bidAmount
        })

        asks.push({
          price: askPrice,
          amount: askAmount,
          total: askPrice * askAmount
        })
      }

      setOrderBook({ bids, asks })
      setIsConnected(true)
    }

    generateMockData()
    
    // به‌روزرسانی هر 3 ثانیه
    const interval = setInterval(generateMockData, 3000)
    
    return () => clearInterval(interval)
  }, [selectedSymbol, selectedTimeframe, showApiSettings, apiConfig])

  const handleSymbolChange = (symbol: string) => {
    setSelectedSymbol(symbol)
  }

  const handleTimeframeChange = (timeframe: string) => {
    setSelectedTimeframe(timeframe)
  }

  const handleRefresh = () => {
    // تازه‌سازی داده‌ها
    const event = new Event('refresh')
    window.dispatchEvent(event)
  }

  const handleApiConfigSave = (config: ApiConfig) => {
    setApiConfig(config)
    // در اینجا می‌توانید اتصال واقعی به API را تست کنید
    console.log('API Config saved:', config)
  }

  const handleConnectToApi = () => {
    if (apiConfig) {
      // Save config to localStorage for TradingDashboard to use
      const tradingConfig = {
        apiKey: apiConfig.apiKey,
        apiSecret: apiConfig.apiSecret,
        symbol: selectedSymbol,
        timeframe: selectedTimeframe,
        atrPeriod: 10,
        multiplier: 3,
        profitPercent: 1,
        lossPercent: 1,
        trailPercent: 0.5,
        amountUsdt: 20,
        leverage: 5,
        marginMode: 'cross',
        useAI: false,
        autoTrade: false
      };
      
      // Save trading configuration to localStorage
      try {
        localStorage.setItem('tradingConfig', JSON.stringify(tradingConfig));
        console.log('Trading configuration saved successfully');
      } catch (error) {
        console.error('Failed to save trading configuration:', error);
        alert('خطا در ذخیره تنظیمات معاملاتی');
        return;
      }
      
      // در اینجا اتصال واقعی به API کوینکس برقرار می‌شود
      setIsConnected(true)
      setShowApiSettings(false)
    }
  }

  const handleSaveApiSettings = () => {
    if (!apiKey.trim() || !apiSecret.trim()) {
      alert('لطفاً API Key و API Secret را وارد کنید')
      return
    }

    // Save API config
    handleApiConfigSave({
      apiKey: apiKey.trim(),
      apiSecret: apiSecret.trim(),
      useProxy
    })
    
    // Save trading configuration to localStorage for TradingDashboard to use
    const tradingConfig = {
      apiKey: apiKey.trim(),
      apiSecret: apiSecret.trim(),
      symbol: selectedSymbol,
      timeframe: selectedTimeframe,
      atrPeriod: 10,
      multiplier: 3,
      profitPercent: 1,
      lossPercent: 1,
      trailPercent: 0.5,
      amountUsdt: 20,
      leverage: 5,
      marginMode: 'cross',
      useAI: false,
      autoTrade: false
    };
    
    // Save trading configuration to localStorage
    try {
      localStorage.setItem('tradingConfig', JSON.stringify(tradingConfig));
      console.log('Trading configuration saved successfully');
      setIsConnected(true)
      setShowApiSettings(false)
    } catch (error) {
      console.error('Failed to save trading configuration:', error);
      alert('خطا در ذخیره تنظیمات معاملاتی');
    }
  }

  const handleTestConnection = () => {
    if (!apiKey.trim() || !apiSecret.trim()) {
      alert('لطفاً API Key و API Secret را وارد کنید')
      return
    }

    setIsTesting(true)
    setTimeout(() => {
      setIsTesting(false)
      handleApiConfigSave({
        apiKey: apiKey.trim(),
        apiSecret: apiSecret.trim(),
        useProxy
      })
    }, 2000)
  }

  if (showApiSettings) {
    return (
      <div className="container mx-auto p-6 min-h-screen flex items-center justify-center">
        <div className="w-full max-w-6xl">
          <div className="text-center mb-8">
            <div className="mb-4 flex flex-wrap gap-2 justify-center">
              <Link href="/tradingview-test">
                <Button variant="outline">
                  <Code className="w-4 h-4 mr-2" />
                  نمودار تریدینگ ویو
                </Button>
              </Link>
            </div>
            <h1 className="text-4xl font-bold mb-2">Trading Dashboard</h1>
            <p className="text-muted-foreground">
              برای شروع، لطفاً تنظیمات را وارد کنید
            </p>
          </div>
          
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="w-5 h-5" />
                <span>تنظیمات معاملاتی و API</span>
                {isConnected && (
                  <Badge variant="default" className="ml-auto">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    متصل
                  </Badge>
                )}
                {!isConnected && isTesting && (
                  <Badge variant="secondary" className="ml-auto">
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                    در حال تست
                  </Badge>
                )}
                {!isConnected && !isTesting && (
                  <Badge variant="destructive" className="ml-auto">
                    <XCircle className="w-3 h-3 mr-1" />
                    قطع
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                تنظیمات API کوینکس و پارامترهای معاملاتی را وارد کنید
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-8">
              {/* API Configuration Section */}
              <div className="space-y-6">
                <h3 className="text-lg font-semibold border-b pb-2">تنظیمات API کوینکس</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="apiKey" className="flex items-center space-x-2">
                      <Key className="w-4 h-4" />
                      <span>API Key</span>
                    </Label>
                    <Input
                      id="apiKey"
                      type="text"
                      placeholder="API Key خود را وارد کنید"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      className="font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      API Key را از پنل کاربری کوینکس دریافت کنید
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="apiSecret" className="flex items-center space-x-2">
                      <Shield className="w-4 h-4" />
                      <span>API Secret</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="apiSecret"
                        type={showSecret ? "text" : "password"}
                        placeholder="API Secret خود را وارد کنید"
                        value={apiSecret}
                        onChange={(e) => setApiSecret(e.target.value)}
                        className="font-mono text-sm pr-10"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2"
                        onClick={() => setShowSecret(!showSecret)}
                      >
                        {showSecret ? "مخفی" : "نمایش"}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      API Secret را به هیچ‌کس فاش نکنید
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="useProxy"
                    checked={useProxy}
                    onCheckedChange={setUseProxy}
                  />
                  <Label htmlFor="useProxy">استفاده از پروکسی (برای رفع مشکل CORS)</Label>
                </div>
                <p className="text-xs text-muted-foreground">
                  {useProxy 
                    ? "درخواست‌ها از طریق پروکسی سرور ارسال می‌شوند"
                    : "درخواست‌ها مستقیماً به API کوینکس ارسال می‌شوند"
                  }
                </p>
              </div>

              <Separator />

              {/* Trading Configuration Section */}
              <div className="space-y-6">
                <h3 className="text-lg font-semibold border-b pb-2">تنظیمات معاملاتی</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="symbol">نماد معاملاتی</Label>
                    <Select value={selectedSymbol} onValueChange={setSelectedSymbol}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BTCUSDT">BTC/USDT</SelectItem>
                        <SelectItem value="ETHUSDT">ETH/USDT</SelectItem>
                        <SelectItem value="XRPUSDT">XRP/USDT</SelectItem>
                        <SelectItem value="ADAUSDT">ADA/USDT</SelectItem>
                        <SelectItem value="DOTUSDT">DOT/USDT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="timeframe">تایم‌فریم</Label>
                    <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1m">1 دقیقه</SelectItem>
                        <SelectItem value="5m">5 دقیقه</SelectItem>
                        <SelectItem value="15m">15 دقیقه</SelectItem>
                        <SelectItem value="30m">30 دقیقه</SelectItem>
                        <SelectItem value="1h">1 ساعت</SelectItem>
                        <SelectItem value="4h">4 ساعت</SelectItem>
                        <SelectItem value="1d">1 روز</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="leverage">اهرم</Label>
                    <Input
                      id="leverage"
                      type="number"
                      min="1"
                      max="125"
                      placeholder="5"
                      defaultValue="5"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="amount">مبلغ معامله (USDT)</Label>
                    <Input
                      id="amount"
                      type="number"
                      min="1"
                      placeholder="20"
                      defaultValue="20"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="margin">حاشیه (Margin Mode)</Label>
                    <Select defaultValue="cross">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cross">Cross</SelectItem>
                        <SelectItem value="isolated">Isolated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-6">
                <Button 
                  variant="outline" 
                  onClick={handleTestConnection}
                  disabled={isTesting}
                >
                  {isTesting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      در حال تست
                    </>
                  ) : (
                    'تست اتصال'
                  )}
                </Button>
                
                <Button onClick={handleSaveApiSettings}>
                  ذخیره تنظیمات و شروع
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 min-h-screen">
      <div className="mb-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Trading Dashboard</h1>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={handleRefresh}
            >
              تازه‌سازی
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setShowApiSettings(true)}
            >
              تنظیمات API
            </Button>
          </div>
        </div>
      </div>
      
      <TradingDashboard
        marketData={marketData}
        candleData={candleData}
        orderBook={orderBook}
        onSymbolChange={handleSymbolChange}
        onTimeframeChange={handleTimeframeChange}
        isConnected={isConnected}
        onRefresh={handleRefresh}
      />
    </div>
  )
}