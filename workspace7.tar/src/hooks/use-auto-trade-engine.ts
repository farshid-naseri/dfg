'use client';

import { useEffect, useCallback, useState } from 'react';
import { useTradingEngine } from './use-trading-engine';
import { AutoTradeEngine, AutoTradeConfig, CandleData } from '@/lib/auto-trade-engine';

export function useAutoTradeEngine() {
  const { tradingEngine, isConnected, candles, config } = useTradingEngine();
  const [autoTradeEngine, setAutoTradeEngine] = useState<AutoTradeEngine | null>(null);

  // 初始化自动交易引擎
  useEffect(() => {
    if (tradingEngine) {
      const engine = new AutoTradeEngine(tradingEngine);
      setAutoTradeEngine(engine);

      return () => {
        engine.stop();
        engine.removeAllListeners();
      };
    }
  }, [tradingEngine]);

  // 处理K线数据更新
  useEffect(() => {
    if (!autoTradeEngine || !candles || candles.length === 0) {
      return;
    }

    // 获取最新的K线数据
    const latestCandle = candles[candles.length - 1];
    
    // 转换为CandleData格式
    const candleData: CandleData = {
      timestamp: latestCandle.timestamp,
      open: latestCandle.open,
      high: latestCandle.high,
      low: latestCandle.low,
      close: latestCandle.close,
      volume: latestCandle.volume
    };

    // 更新自动交易引擎的K线数据
    autoTradeEngine.updateCandleData(candleData);
  }, [candles, autoTradeEngine]);

  // 批量更新K线数据（初始化时）
  useEffect(() => {
    if (!autoTradeEngine || !candles || candles.length === 0) {
      return;
    }

    // 转换所有K线数据
    const candleDataList: CandleData[] = candles.map(candle => ({
      timestamp: candle.timestamp,
      open: candle.open,
      high: candle.high,
      low: candle.low,
      close: candle.close,
      volume: candle.volume
    }));

    // 批量更新自动交易引擎的K线数据
    autoTradeEngine.updateCandleBatch(candleDataList);
  }, [autoTradeEngine]);

  // 启动自动交易
  const startAutoTrade = useCallback((strategyConfig: AutoTradeConfig) => {
    if (!autoTradeEngine) {
      throw new Error('Auto trade engine not initialized');
    }

    return autoTradeEngine.start(strategyConfig);
  }, [autoTradeEngine]);

  // 停止自动交易
  const stopAutoTrade = useCallback(() => {
    if (!autoTradeEngine) {
      return;
    }

    autoTradeEngine.stop();
  }, [autoTradeEngine]);

  // 获取信号日志
  const getSignalLogs = useCallback(() => {
    if (!autoTradeEngine) {
      return [];
    }

    return autoTradeEngine.getSignalLogs();
  }, [autoTradeEngine]);

  // 清除信号日志
  const clearSignalLogs = useCallback(() => {
    if (!autoTradeEngine) {
      return;
    }

    autoTradeEngine.clearSignalLogs();
  }, [autoTradeEngine]);

  // 获取状态
  const getStatus = useCallback(() => {
    if (!autoTradeEngine) {
      return null;
    }

    return autoTradeEngine.getStatus();
  }, [autoTradeEngine]);

  return {
    autoTradeEngine,
    isConnected,
    startAutoTrade,
    stopAutoTrade,
    getSignalLogs,
    clearSignalLogs,
    getStatus,
    config
  };
}