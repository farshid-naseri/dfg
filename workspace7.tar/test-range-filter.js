// Test Range Filter strategy with mock data
const mockCandles = [
  { timestamp: Date.now() - 300000, open: 2.0, high: 2.1, low: 1.9, close: 2.05, volume: 1000 },
  { timestamp: Date.now() - 240000, open: 2.05, high: 2.2, low: 2.0, close: 2.15, volume: 1000 },
  { timestamp: Date.now() - 180000, open: 2.15, high: 2.3, low: 2.1, close: 2.25, volume: 1000 },
  { timestamp: Date.now() - 120000, open: 2.25, high: 2.4, low: 2.2, close: 2.35, volume: 1000 },
  { timestamp: Date.now() - 60000, open: 2.35, high: 2.5, low: 2.3, close: 2.45, volume: 1000 },
  { timestamp: Date.now(), open: 2.45, high: 2.6, low: 2.4, close: 2.55, volume: 1000 }
];

console.log('Testing Range Filter strategy with mock data...');
console.log('Mock candles:', mockCandles);

// Test parameters
const parameters = {
  rng_qty: 0.1,
  rng_per: 20,
  smooth_range: true,
  smooth_per: 27
};

console.log('Parameters:', parameters);

// Simulate the strategy calculation
const closes = mockCandles.map(d => d.close);
const n = closes.length;

console.log('Closes:', closes);

// Calculate AC input (absolute differences)
const ac_input = new Array(n).fill(NaN);
for (let i = 1; i < n; i++) {
  ac_input[i] = Math.abs(closes[i] - closes[i-1]);
}

console.log('AC input:', ac_input);

// Calculate EMA for AC input (rng_per)
function calculateEMA(values, period) {
  const ema = [];
  const multiplier = 2 / (period + 1);
  
  let sum = 0;
  for (let i = 0; i < period && i < values.length; i++) {
    sum += values[i];
  }
  if (values.length >= period) {
    ema[period - 1] = sum / period;
  }
  
  for (let i = period; i < values.length; i++) {
    ema[i] = (values[i] - ema[i - 1]) * multiplier + ema[i - 1];
  }
  
  return ema;
}

const AC = calculateEMA(ac_input, parameters.rng_per);
console.log('AC (EMA):', AC);

// Calculate raw range
const raw_range = AC.map(v => Number.isNaN(v) ? NaN : v * parameters.rng_qty);
console.log('Raw range:', raw_range);

// Calculate smoothed range
const r_series = parameters.smooth_range ? calculateEMA(raw_range, parameters.smooth_per) : raw_range.slice();
console.log('R series (smoothed range):', r_series);

// Calculate filter
const filt = new Array(n).fill(NaN);
let rfilt_prev = n > 0 ? closes[0] : NaN;
for (let i = 0; i < n; i++) {
  const r = r_series[i];
  const c = closes[i];
  const prev = rfilt_prev;
  let rfilt_curr = prev;
  if (!Number.isNaN(r)) {
    if (c - r > prev) rfilt_curr = c - r;
    if (c + r < prev) rfilt_curr = c + r;
  }
  filt[i] = rfilt_curr;
  rfilt_prev = rfilt_curr;
}

console.log('Filter:', filt);

// Calculate direction
const fdir = new Array(n).fill(NaN);
let var_fdir = 0.0;
let prev_filt = NaN;
for (let i = 0; i < n; i++) {
  if (i === 0 || Number.isNaN(filt[i]) || Number.isNaN(prev_filt)) {
    fdir[i] = var_fdir;
  } else {
    if (filt[i] > prev_filt) var_fdir = 1.0;
    else if (filt[i] < prev_filt) var_fdir = -1.0;
    fdir[i] = var_fdir;
  }
  prev_filt = filt[i];
}

console.log('Direction (fdir):', fdir);

// Calculate conditions
const upward = fdir.map(v => v === 1.0);
const downward = fdir.map(v => v === -1.0);

console.log('Upward:', upward);
console.log('Downward:', downward);

// Calculate long and short conditions
const longCond = new Array(n).fill(false);
const shortCond = new Array(n).fill(false);
for (let i = 0; i < n; i++) {
  if (!Number.isNaN(filt[i]) && closes[i] > filt[i] && upward[i]) longCond[i] = true;
  if (!Number.isNaN(filt[i]) && closes[i] < filt[i] && downward[i]) shortCond[i] = true;
}

console.log('Long conditions:', longCond);
console.log('Short conditions:', shortCond);

// Calculate signals
const CondIni = new Array(n).fill(0);
const buy = new Array(n).fill(false);
const sell = new Array(n).fill(false);
for (let i = 0; i < n; i++) {
  const prev_ini = i > 0 ? CondIni[i-1] : 0;
  if (longCond[i] && prev_ini === -1) buy[i] = true;
  if (shortCond[i] && prev_ini === 1) sell[i] = true;
  if (longCond[i]) CondIni[i] = 1;
  else if (shortCond[i]) CondIni[i] = -1;
  else CondIni[i] = prev_ini;
}

console.log('CondIni:', CondIni);
console.log('Buy signals:', buy);
console.log('Sell signals:', sell);

// Show final results
for (let i = 0; i < n; i++) {
  console.log(`Candle ${i}: Close=${closes[i]}, Filter=${filt[i]}, Direction=${fdir[i]}, Buy=${buy[i]}, Sell=${sell[i]}`);
}