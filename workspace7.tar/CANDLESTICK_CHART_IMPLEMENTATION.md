# Candlestick Chart Implementation

This document describes the implementation of advanced candlestick charts using Lightweight Charts library for the cryptocurrency trading system.

## Overview

We've implemented two advanced candlestick chart components based on the provided sample code:

1. **Improved Candlestick Chart** - Enhanced version with simulated real-time data
2. **WebSocket Candlestick Chart** - Real-time data integration with CoinEx WebSocket

## Installation

The Lightweight Charts library was installed using:

```bash
npm install lightweight-charts
```

## Components

### 1. Improved Candlestick Chart (`/src/components/improved-candlestick-chart.tsx`)

**Location**: `/improved-candlestick-chart`

**Features**:
- Real candlestick chart visualization using Lightweight Charts
- Historical data loading from CoinEx API
- Simulated real-time price updates every 2 seconds
- Multiple cryptocurrency support (BTC, ETH, XRP, ADA, SOL)
- 11 timeframes (1m to 1d)
- Current candle information display
- Responsive design with RTL support
- Professional dark theme

**Key Implementation Details**:
- Uses `lightweight-charts/dist/lightweight-charts.production.mjs` for ES module compatibility
- Implements candle building logic similar to the Python sample
- Simulates price movements with realistic volatility
- Handles chart resizing and cleanup properly

### 2. WebSocket Candlestick Chart (`/src/components/websocket-candlestick-chart.tsx`)

**Location**: `/websocket-candlestick-chart`

**Features**:
- Real-time candlestick chart with live WebSocket data
- CoinEx WebSocket integration for depth data
- API authentication support
- Real-time candle building from order book data
- Connection status monitoring
- Authentication and subscription management
- All features from the improved version

**Key Implementation Details**:
- Uses the existing `useWebSocket` hook for CoinEx integration
- Processes depth data to build candles in real-time
- Implements proper WebSocket connection management
- Handles authentication using CoinEx `server.sign` method
- Provides manual control over WebSocket connections

## Technical Implementation

### Chart Initialization

```typescript
const chart = createChart(chartContainerRef.current, {
  width: chartContainerRef.current.clientWidth,
  height: 500,
  layout: {
    background: { color: '#131722' },
    textColor: '#d1d4dc',
  },
  grid: {
    vertLines: { color: '#334158' },
    horzLines: { color: '#334158' },
  },
  timeScale: {
    timeVisible: true,
    secondsVisible: false,
  },
})

const candleSeries = chart.addCandlestickSeries({
  upColor: '#26a69a',
  downColor: '#ef5350',
  borderUpColor: '#26a69a',
  borderDownColor: '#ef5350',
  wickUpColor: '#26a69a',
  wickDownColor: '#ef5350',
})
```

### Candle Building Logic

The implementation follows the pattern from the Python sample:

```typescript
const processDepthData = (depthData: DepthData) => {
  const bidPrice = depthData.bids[0]?.[0] || 0
  const askPrice = depthData.asks[0]?.[0] || 0
  const midPrice = (bidPrice + askPrice) / 2

  const now = Math.floor(Date.now() / 1000)
  const timeframeSeconds = timeframes.find(tf => tf.value === selectedTimeframe)?.seconds || 300
  const candleTime = Math.floor(now / timeframeSeconds) * timeframeSeconds

  if (!currentCandleRef.current || currentCandleRef.current.time !== candleTime) {
    // New candle
    const newCandle: CandleData = {
      time: candleTime,
      open: midPrice,
      high: midPrice,
      low: midPrice,
      close: midPrice,
      volume: Math.random() * 1000
    }
    currentCandleRef.current = newCandle
    candleSeriesRef.current.update(newCandle)
  } else {
    // Update current candle
    const updatedCandle = {
      ...currentCandleRef.current,
      high: Math.max(currentCandleRef.current.high, midPrice),
      low: Math.min(currentCandleRef.current.low, midPrice),
      close: midPrice,
      volume: (currentCandleRef.current.volume || 0) + Math.random() * 100
    }
    currentCandleRef.current = updatedCandle
    candleSeriesRef.current.update(updatedCandle)
  }
}
```

### Historical Data Loading

```typescript
const loadHistoricalData = async () => {
  const historicalData = await fetchHistoricalData()
  
  const formattedData = historicalData.map(candle => ({
    time: candle.time,
    open: candle.open,
    high: candle.high,
    low: candle.low,
    close: candle.close
  }))
  
  if (candleSeriesRef.current) {
    candleSeriesRef.current.setData(formattedData)
  }
}
```

## WebSocket Integration

The WebSocket version integrates with the existing CoinEx WebSocket manager:

```typescript
const {
  isConnected: wsConnected,
  isAuthenticated: wsAuthenticated,
  connect,
  disconnect,
  authenticate,
  subscribeToDepth,
  unsubscribeFromDepth
} = useWebSocket({
  url: 'wss://socket.coinex.com/v2/futures',
  apiKey,
  apiSecret,
  onMessage: (message) => {
    if (message.method === 'depth.update' && message.data && message.data.depth) {
      const depthData: DepthData = {
        bids: message.data.depth.bids || [],
        asks: message.data.depth.asks || []
      }
      processDepthData(depthData)
    }
  }
})
```

## Usage

### Accessing the Charts

1. **Improved Candlestick Chart**: Visit `http://localhost:3000/improved-candlestick-chart`
2. **WebSocket Candlestick Chart**: Visit `http://localhost:3000/websocket-candlestick-chart`

### Features Available

- **Symbol Selection**: Choose from BTC, ETH, XRP, ADA, SOL
- **Timeframe Selection**: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 12h, 1d
- **Real-time Updates**: Simulated or WebSocket-based price updates
- **Current Candle Info**: Detailed information about the active candle
- **Connection Status**: Monitor WebSocket connection and authentication

## Comparison with Original Implementation

| Feature | Original (Chart.js) | New (Lightweight Charts) |
|---------|-------------------|-------------------------|
| Chart Type | Line chart | Real candlestick chart |
| Performance | Good | Excellent |
| Visual Quality | Basic | Professional |
| Real-time Updates | Simulated | Simulated + WebSocket |
| Interactivity | Basic | Advanced |
| Data Processing | Simple | Sophisticated |
| Theme | Light | Professional Dark |

## Dependencies

- `lightweight-charts`: Professional charting library
- `react`: UI framework
- `nextjs`: Application framework
- `typescript`: Type safety
- `tailwindcss`: Styling
- `shadcn/ui`: UI components

## Future Enhancements

1. **Technical Indicators**: Add ATR, Supertrend, and other indicators
2. **Drawing Tools**: Support for trend lines, Fibonacci retracements
3. **Multiple Timeframes**: Display multiple timeframes simultaneously
4. **Backtesting Integration**: Connect with strategy backtesting
5. **Alert System**: Price and technical condition alerts
6. **Export Functionality**: Chart image and data export

## Troubleshooting

### Common Issues

1. **Import Errors**: Ensure using the correct ES module path
2. **WebSocket Connection**: Check API credentials and network connectivity
3. **Chart Rendering**: Verify container dimensions and responsive behavior
4. **Data Updates**: Monitor console for data processing errors

### Debug Mode

Enable debug logging by checking the browser console for:
- Chart initialization messages
- WebSocket connection status
- Data processing logs
- Error messages

## Conclusion

The new candlestick chart implementations provide a professional-grade trading interface with real-time data visualization, following the patterns established in the provided Python sample code. The implementation leverages modern web technologies and best practices for performance and user experience.